"""2차 수집 29장 카드의 품질을 기계적으로 점검한다(서버 results.json 기준).

  python eval/quality_round2.py eval/round2_results_v3.json --out eval/quality_round2.md

점검 항목
  1. 문구 수·판정 분포(제품별), 대조군 5개의 오탐(‘AI’를 내세우지 않는 제품에서 뽑힌 문구)
  2. 근거 인용이 실제 문서 청크에 있는지(doc_id·chunk·quote 일치)
  3. 문구가 실제 판매페이지 문장인지(원문에 있는지)
  4. 쉬운 말 문장 길이·금지 표현(평가·권고)
  5. 권익 7항목 공개 여부 분포
  6. 의심 패턴: 조각(문장 끝 아님), 제품명만, 영어 문구, 되풀이
"""
import argparse
import json
import re
from collections import Counter
from pathlib import Path

END = re.compile(r"((다|요|죠|음|함|됨|니다|세요|습니다|입니다)[\.\!\?\)\*\s]*$|[\.\!\?][\)\*\s]*$)")
BAD_EASY = re.compile(r"(좋습니다|나쁩니다|추천|권장|우수|뛰어나|믿을 만|의심|거짓|과장|위법|불법)")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("results")
    ap.add_argument("--out", default="eval/quality_round2.md")
    ap.add_argument("--collect", default="eval/collect")
    a = ap.parse_args()
    res = json.load(open(a.results, encoding="utf-8"))
    controls = set()
    for f in Path(a.collect).glob("*.json"):
        try:
            if json.load(open(f, encoding="utf-8")).get("control"):
                controls.add(f.stem)
        except Exception:
            pass

    rows = []
    issues: list[str] = []
    status_total: Counter = Counter()
    item_total: Counter = Counter()
    for slug, info in sorted(res["pushed"].items()):
        ex = res["exports"].get(str(info["pid"]))
        if not ex or not ex.get("card"):
            issues.append(f"- {slug}: 카드 없음")
            continue
        card = ex["card"]
        docs = {d["id"]: d for d in ex["documents"]}
        claims = card.get("claims", [])
        st = Counter(c["status"] for c in claims)
        status_total.update(st)
        n_ev_bad = n_frag = n_eng = n_name = 0
        for c in claims:
            t = c["text"].strip()
            if not END.search(t) and not re.search(r"[가-힣]$", t):
                pass
            if not END.search(t):
                n_frag += 1
            if not re.search(r"[가-힣]", t):
                n_eng += 1
            # 문구가 원문에 있는가
            src = c.get("source") or {}
            d = docs.get(src.get("doc_id"))
            if d and t[:12] not in d.get("text", "") and not any(t[:12] in ch for ch in d.get("chunks", [])):
                issues.append(f"- {slug} c{c.get('id','?')}: 문구가 원문에 없음 → {t[:60]}")
            for e in c.get("evidence", []):
                d = docs.get(e.get("doc_id"))
                ok = bool(d) and any(e.get("quote", "")[:20] in ch for ch in d.get("chunks", []))
                if not ok:
                    n_ev_bad += 1
                    issues.append(f"- {slug} c{c.get('id','?')}: 근거 인용이 문서에 없음 → {e.get('quote','')[:60]}")
            if c["status"] in ("근거 확인", "조건 확인") and not c.get("evidence"):
                issues.append(f"- {slug} c{c.get('id','?')}: 근거 없이 '{c['status']}'")
            if c["status"] == "조건 확인" and not c.get("conditions"):
                issues.append(f"- {slug} c{c.get('id','?')}: '조건 확인'인데 조건 문장 비어 있음")
        # 되풀이
        texts = [re.sub(r"\W", "", c["text"]) for c in claims]
        for i in range(len(texts)):
            for j in range(i + 1, len(texts)):
                a_, b_ = texts[i], texts[j]
                if a_ and b_ and (a_[:20] == b_[:20]):
                    issues.append(f"- {slug}: 되풀이 의심 → {claims[i]['text'][:40]} / {claims[j]['text'][:40]}")
        # 쉬운 말
        easy = card.get("easy") or {}
        easy_lines = []
        if isinstance(easy, dict):
            for v in easy.values():
                if isinstance(v, str):
                    easy_lines.append(v)
                elif isinstance(v, list):
                    easy_lines.extend(x if isinstance(x, str) else json.dumps(x, ensure_ascii=False) for x in v)
        for ln in easy_lines:
            if BAD_EASY.search(ln):
                issues.append(f"- {slug} 쉬운 말에 평가·권고 표현 → {ln[:60]}")
        # 권익
        items = card.get("items") or {}
        for k, v in (items.items() if isinstance(items, dict) else []):
            item_total[(k, (v.get("status") if isinstance(v, dict) else str(v)))] += 1
        ctrl = slug in controls
        if ctrl and len(claims) > 0:
            issues.append(f"- {slug} (대조군): 문구 {len(claims)}개 추출됨 → " + " / ".join(c['text'][:30] for c in claims[:3]))
        rows.append((slug, ex["product"]["name"][:28], "대조군" if ctrl else "", len(claims), st.get("근거 확인", 0), st.get("조건 확인", 0),
                     st.get("자료 부족", 0), st.get("추가 확인 필요", 0), n_frag, n_eng, n_ev_bad, len(ex["documents"])))

    out = ["# 2차 카드 29장 품질 점검", "", f"원본: {a.results}", "",
           "## 1. 제품별", "",
           "| slug | 제품 | 대조군 | 문구 | 근거 | 조건 | 자료부족 | 어긋남 | 조각 | 영어 | 근거오류 | 문서 |", "|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for r in rows:
        out.append("| " + " | ".join(str(x) for x in r) + " |")
    out += ["", "## 2. 판정 분포", "", "| 판정 | 수 |", "|---|---|"]
    for k, v in status_total.most_common():
        out.append(f"| {k} | {v} |")
    out += ["", "## 3. 권익 항목 공개 여부", "", "| 항목 | 상태 | 수 |", "|---|---|---|"]
    for (k, s), v in sorted(item_total.items()):
        out.append(f"| {k} | {s} | {v} |")
    out += ["", f"## 4. 의심 항목 ({len(issues)}건)", ""] + (issues or ["- 없음"])
    Path(a.out).write_text("\n".join(out), encoding="utf-8")
    print("\n".join(out))


if __name__ == "__main__":
    main()
