"""2차 수집분(collect/*.json)을 서버에 올려 카드 초안을 만들고, 결과를 로컬 DB로 가져온다.

서버는 LLM 키가 있는 곳(Render 또는 소민 PC의 로컬 서버)이어야 한다. LLM 호출 수(카드당): OCR 묶음 n회 + 추출 1 + 연결 1 + 권익 1 + 쉬운 말 1.

  python eval/round2_ingest.py push --base https://aicard-3b2h.onrender.com --token lucky7 --dir <collect 폴더>
  python eval/round2_ingest.py status --base ... --token ...
  python eval/round2_ingest.py pull --base ... --token ... --db data/aicard.sqlite3

push 는 collect/pushed.json 에 slug→서버 product_id 를 적는다. 이미 올린 slug 는 건너뛴다.
pull 은 서버의 제품·문서·카드를 받아 로컬 DB에 새 제품으로 넣는다(문서 doc_id 는 다시 매긴다).
"""
import argparse
import glob
import json
import os
import sys
import time
from pathlib import Path

import httpx

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


def client(base: str, token: str) -> httpx.Client:
    c = httpx.Client(base_url=base, timeout=600, follow_redirects=False)
    r = c.post("/review/login", data={"token": token})
    if r.status_code not in (302, 303):
        sys.exit(f"로그인 실패 {r.status_code}")
    return c


def cmd_push(a) -> None:
    d = Path(a.dir)
    pushed_p = d / "pushed.json"
    pushed = json.load(open(pushed_p, encoding="utf-8")) if pushed_p.exists() else {}
    files = sorted(glob.glob(str(d / "*.json")))
    files = [f for f in files if Path(f).name not in ("pushed.json",)]
    c = client(a.base, a.token)
    n_img = 0
    for f in files:
        slug = Path(f).stem
        if slug in pushed:
            continue
        j = json.load(open(f, encoding="utf-8"))
        if a.only and slug not in a.only:
            continue
        body = {"name": j.get("name") or j.get("title", "")[:80], "maker": j.get("maker", ""), "model": j.get("model", ""),
                "category": j.get("category", "로봇청소기"), "url": j.get("url", ""), "title": j.get("title", ""),
                "sales_text": j.get("sales_text", ""), "fine_text": j.get("fine_text", ""),
                "image_urls": j.get("image_urls", [])[:60]}
        r = c.post("/api/ingest", json=body)
        if r.status_code != 200:
            print(f"  {slug}: 실패 {r.status_code} {r.text[:120]}")
            continue
        pid = r.json()["id"]
        pushed[slug] = {"pid": pid, "control": bool(j.get("control")), "at": time.strftime("%Y-%m-%d %H:%M")}
        n_img += len(body["image_urls"])
        print(f"  {slug} → 서버 제품 {pid} (이미지 {len(body['image_urls'])}장)")
        json.dump(pushed, open(pushed_p, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        time.sleep(a.gap)
    print(f"올린 제품 {len(pushed)}개, 이미지 {n_img}장 (OCR 호출 약 {n_img // 6 + len(pushed)}회 + 카드당 4회)")


def cmd_status(a) -> None:
    d = Path(a.dir)
    pushed = json.load(open(d / "pushed.json", encoding="utf-8"))
    c = client(a.base, a.token)
    for slug, info in pushed.items():
        r = c.get(f"/review/{info['pid']}/export.json")
        if r.status_code != 200:
            print(f"  {slug}: {r.status_code}")
            continue
        j = r.json()
        p = j["product"]
        card = j.get("card") or {}
        print(f"  {slug:26s} pid {p['id']:3d} {p['status']:8s} 문서 {len(j['documents'])} 문구 {len(card.get('claims', []))} | {p.get('reviewer_note', '')[:70]}")


def cmd_pull(a) -> None:
    os.environ["AICARD_DB"] = str(Path(a.db).resolve())
    from app import db  # noqa: E402
    d = Path(a.dir)
    pushed = json.load(open(d / "pushed.json", encoding="utf-8"))
    pulled_p = d / "pulled.json"
    pulled = json.load(open(pulled_p, encoding="utf-8")) if pulled_p.exists() else {}
    c = client(a.base, a.token)
    for slug, info in pushed.items():
        if slug in pulled and not a.force:
            continue
        r = c.get(f"/review/{info['pid']}/export.json")
        if r.status_code != 200:
            print(f"  {slug}: 받기 실패 {r.status_code}")
            continue
        j = r.json()
        p, docs, card, meta = j["product"], j["documents"], j.get("card"), j.get("meta") or {}
        if not card:
            print(f"  {slug}: 아직 카드 없음({p['status']}) — 건너뜀")
            continue
        new_pid = db.create_product(p["name"], p.get("maker", ""), p.get("model", ""), p.get("category", ""))
        idmap: dict[int, int] = {}
        for doc in docs:
            nid = db.add_document(new_pid, doc["kind"], doc["title"], doc.get("url", ""), doc.get("text", ""), doc.get("chunks", []))
            idmap[doc["id"]] = nid
        # 카드 안의 doc_id 를 새 번호로 바꾼다
        def remap(o):
            if isinstance(o, dict):
                if "doc_id" in o and o["doc_id"] in idmap:
                    o["doc_id"] = idmap[o["doc_id"]]
                for v in o.values():
                    remap(v)
            elif isinstance(o, list):
                for v in o:
                    remap(v)
        remap(card)
        card["product_id"] = new_pid
        db.save_card(new_pid, card, meta)
        note = ("대조군(‘AI’를 내세우지 않는 제품). " if info.get("control") else "") + "2차 수집 — 검토 대기"
        db.set_product_status(new_pid, "pending", note)
        pulled[slug] = {"local_pid": new_pid, "server_pid": info["pid"]}
        json.dump(pulled, open(pulled_p, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        print(f"  {slug} → 로컬 제품 {new_pid} (문서 {len(docs)}, 문구 {len(card.get('claims', []))})")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["push", "status", "pull"])
    ap.add_argument("--base", required=True)
    ap.add_argument("--token", required=True)
    ap.add_argument("--dir", default=str(ROOT / "eval" / "collect"))
    ap.add_argument("--db", default=str(ROOT / "data" / "aicard.sqlite3"))
    ap.add_argument("--gap", type=float, default=2.0, help="push 간격(초)")
    ap.add_argument("--only", nargs="*", default=None)
    ap.add_argument("--force", action="store_true")
    a = ap.parse_args()
    {"push": cmd_push, "status": cmd_status, "pull": cmd_pull}[a.cmd](a)


if __name__ == "__main__":
    main()
