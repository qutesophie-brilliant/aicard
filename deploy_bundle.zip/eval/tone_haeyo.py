"""카드에 보이는 문장(조건, 권익 항목 요약)의 종결어미를 해요체로 맞춘다.

  python eval/tone_haeyo.py --db data/aicard.sqlite3 [--dry]

화면 문구가 해요체라서 카드 본문도 같은 말투로 맞춘다. 내용은 바꾸지 않는다.
"""
import argparse
import json
import re
import sqlite3

RULES = [
    (r"있습니다\.", "있어요."),
    (r"없습니다\.", "없어요."),
    (r"않습니다\.", "않아요."),
    (r"못했습니다\.", "못했어요."),
    (r"밝힙니다\.", "밝혀요."),
    (r"됩니다\.", "돼요."),
    (r"합니다\.", "해요."),
]


def _ieyo(word: str) -> str:
    ch = word[-1]
    if "가" <= ch <= "힣" and (ord(ch) - 0xAC00) % 28:
        return word + "이에요."
    return word + "예요."


def convert(text: str) -> str:
    if not text:
        return text
    out = text
    for pat, rep in RULES:
        out = re.sub(pat, rep, out)
    out = re.sub(r"([가-힣A-Za-z0-9)\]'’])입니다\.", lambda m: _ieyo(m.group(1)), out)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", required=True)
    ap.add_argument("--dry", action="store_true")
    a = ap.parse_args()
    con = sqlite3.connect(a.db)
    changed = 0
    for pid, js in con.execute("select product_id, card_json from cards").fetchall():
        card = json.loads(js)
        for c in card.get("claims", []):
            new = convert(c.get("conditions", ""))
            if new != c.get("conditions", ""):
                c["conditions"] = new
                changed += 1
        for it in card.get("items", {}).values():
            new = convert(it.get("summary", ""))
            if new != it.get("summary", ""):
                it["summary"] = new
                changed += 1
        if not a.dry:
            con.execute("update cards set card_json=? where product_id=?", (json.dumps(card, ensure_ascii=False), pid))
    if not a.dry:
        con.commit()
    print(f"{'점검만' if a.dry else '반영'}: 문장 {changed}곳")


if __name__ == "__main__":
    main()
