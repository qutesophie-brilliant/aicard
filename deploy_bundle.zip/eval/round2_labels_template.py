"""2차 카드 29장의 문구를 라벨링용 CSV로 뽑는다(사람이 decision·gold_status를 채운다).

  python eval/round2_labels_template.py eval/round2_results_v4.json --out eval/review_round2_labels.csv

열: product_id(서버), slug, product, control, claim_id, claim_text, ai_status, ai_evidence, ai_conditions,
    decision(include/exclude), gold_status(근거 확인/조건 확인/자료 부족/추가 확인 필요), gold_evidence_quote, note
라벨 기준은 eval/labeling_guide.md 를 따른다. 1차 라벨(review_round1_labels.csv)과 같은 형식이라 eval/round2.py 로 바로 잴 수 있다.
"""
import argparse
import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("results")
    ap.add_argument("--out", default=str(ROOT / "review_round2_labels.csv"))
    ap.add_argument("--collect", default=str(ROOT / "collect"))
    a = ap.parse_args()
    res = json.load(open(a.results, encoding="utf-8"))
    controls = set()
    for f in Path(a.collect).glob("*.json"):
        try:
            if json.load(open(f, encoding="utf-8")).get("control"):
                controls.add(f.stem)
        except Exception:
            pass
    rows = []
    for slug, info in sorted(res["pushed"].items()):
        ex = res["exports"].get(str(info["pid"]))
        if not ex or not ex.get("card"):
            continue
        for c in ex["card"].get("claims", []):
            ev = " || ".join(e.get("quote", "")[:160] for e in c.get("evidence", [])[:3])
            rows.append({
                "product_id": info["pid"], "slug": slug, "product": ex["product"]["name"],
                "control": "Y" if slug in controls else "",
                "claim_id": c.get("id", ""), "claim_text": c["text"],
                "ai_status": c.get("status", ""), "ai_evidence": ev, "ai_conditions": c.get("conditions", ""),
                "decision": "", "gold_status": "", "gold_evidence_quote": "", "labeler": "", "note": "",
            })
    with open(a.out, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    print(f"{len(rows)}개 문구 → {a.out}  (제품 {len(res['pushed'])}개)")


if __name__ == "__main__":
    main()
