"""독립 라벨러 3인의 일치도(Fleiss κ, 쌍별 Cohen κ).

사용: python eval/kappa.py eval/heldout3
labels_A.csv·labels_B.csv·labels_C.csv에서 (pid, claim_id)가 셋 모두에 있는 문구만 쓴다.
"""
import collections
import csv
import sys
from itertools import combinations
from pathlib import Path


def load(p: Path) -> dict:
    out = {}
    with open(p, encoding="utf-8-sig") as f:
        for r in csv.DictReader(f):
            out[(r["pid"], r["claim_id"])] = (r["decision"].strip(), r["gold_status"].strip())
    return out


def fleiss(rows: list[list[str]]) -> tuple[float, float, float]:
    cats = sorted({c for row in rows for c in row})
    n_items, n_raters = len(rows), len(rows[0])
    p_i, totals = [], collections.Counter()
    for row in rows:
        cnt = collections.Counter(row)
        totals.update(cnt)
        p_i.append((sum(v * v for v in cnt.values()) - n_raters) / (n_raters * (n_raters - 1)))
    p_bar = sum(p_i) / n_items
    p_e = sum((totals[c] / (n_items * n_raters)) ** 2 for c in cats)
    return (p_bar - p_e) / (1 - p_e), p_bar, p_e


def cohen(a: list[str], b: list[str]) -> float:
    n = len(a)
    po = sum(x == y for x, y in zip(a, b)) / n
    ca, cb = collections.Counter(a), collections.Counter(b)
    pe = sum(ca[k] * cb[k] for k in set(a) | set(b)) / (n * n)
    return (po - pe) / (1 - pe)


def landis(k: float) -> str:
    for lim, name in [(0.2, "slight"), (0.4, "fair"), (0.6, "moderate"), (0.8, "substantial"), (1.01, "almost perfect")]:
        if k < lim:
            return name
    return "almost perfect"


def main(folder: str) -> None:
    d = Path(folder)
    labs = {x: load(d / f"labels_{x}.csv") for x in "ABC"}
    common = sorted(set.intersection(*(set(v) for v in labs.values())))
    dec = [[labs[x][k][0] for x in "ABC"] for k in common]
    k, pb, pe = fleiss(dec)
    print(f"추출 여부(include/exclude): 문구 {len(dec)}, 만장일치 {sum(len(set(r)) == 1 for r in dec)}, P̄ {pb:.3f}, Pe {pe:.3f}, Fleiss κ {k:.3f} ({landis(k)})")
    st = [[labs[x][k][1] for x in "ABC"] for k in common if all(labs[x][k][0] == "include" and labs[x][k][1] for x in "ABC")]
    k, pb, pe = fleiss(st)
    print(f"확인상태(3인 모두 include): 문구 {len(st)}, 만장일치 {sum(len(set(r)) == 1 for r in st)}, P̄ {pb:.3f}, Pe {pe:.3f}, Fleiss κ {k:.3f} ({landis(k)})")
    two = [["있음" if s in ("근거 확인", "조건 확인") else "없음" for s in r] for r in st]
    k, pb, pe = fleiss(two)
    print(f"근거 유무 2분류: Fleiss κ {k:.3f} ({landis(k)})")
    cols = list(zip(*st))
    for (na, a), (nb, b) in combinations(zip("ABC", cols), 2):
        print(f"쌍별 Cohen κ(확인상태) {na}-{nb}: {cohen(list(a), list(b)):.3f}")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "eval/heldout3")
