"""새 품목 12개의 최종 정확도를 두 축으로 잰다(라벨 확정 후 한 번만 돌린다).

  python eval/round4_score.py --dir eval/heldout4 --labels eval/heldout4/gold_final.csv

축 1 근거상태(있음·없음·어긋남), 축 2 조건표시(축 1이 양쪽 '있음'인 문구에서만).
4분류는 참고로만 적는다. 대조군은 따로 집계한다(AI 문구 0개가 정답).
"""
import argparse
import csv
import json
from collections import Counter, defaultdict
from pathlib import Path

POS = {"근거 확인", "조건 확인"}
B = ["있음", "없음", "어긋남"]
YES = {"예", "y", "yes", "true", "1", "o"}


def status_from(basis: str, cond: bool) -> str:
    if basis == "어긋남":
        return "추가 확인 필요"
    if basis == "있음":
        return "조건 확인" if cond else "근거 확인"
    return "자료 부족"


def axes(status: str) -> tuple[str, bool]:
    if status == "추가 확인 필요":
        return "어긋남", False
    if status in POS:
        return "있음", status == "조건 확인"
    return "없음", False


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", default="eval/heldout4")
    ap.add_argument("--labels", default=None)
    ap.add_argument("--out", default=None)
    a = ap.parse_args()
    d = Path(a.dir)
    pred = json.load(open(d / "pred.json", encoding="utf-8"))
    labels = a.labels or str(d / "gold_final.csv")
    rows, excluded, ctrl = [], 0, []
    for r in csv.DictReader(open(labels, encoding="utf-8-sig")):
        key = f"{r['pid']}:{r['claim_id']}"
        if r.get("control") == "Y":
            ctrl.append(key)
        if (r.get("decision") or "").strip() != "include":
            excluded += 1
            continue
        basis = (r.get("basis") or "").strip()
        if basis not in B:
            raise SystemExit(f"{key}: basis 값이 비었거나 잘못됨({basis!r})")
        gold = status_from(basis, (r.get("conditions_noted") or "").strip().lower() in YES)
        p = pred.get(key)
        if not p:
            raise SystemExit(f"{key}: 판정이 없음 — 라벨 표와 pred.json 이 어긋남")
        got = p.get("status") or status_from(p.get("basis_state", ""), p.get("conditions_noted", False))
        rows.append((gold, got, key))

    n = len(rows)
    ax = [(axes(g), axes(p)) for g, p, _ in rows]
    b_ok = sum(ga == pa for (ga, _), (pa, _) in ax)
    bconf: dict[str, Counter] = defaultdict(Counter)
    for (ga, _), (pa, _) in ax:
        bconf[ga][pa] += 1
    both = [(gc, pc) for (ga, gc), (pa, pc) in ax if ga == pa == "있음"]
    c_hit = sum(gc and pc for gc, pc in both)
    c_gold = sum(gc for gc, _ in both)
    c_pred = sum(pc for _, pc in both)
    L = []
    L.append(f"대상 문구 {n}개 (라벨러가 제외한 문구 {excluded}개, 대조군 문구 {len(ctrl)}개)")
    L.append(f"축1 근거상태 정확도 {b_ok}/{n} = {b_ok/n*100:.1f}%")
    L.append(f"4분류(참고) {sum(g==p for g,p,_ in rows)}/{n} = {sum(g==p for g,p,_ in rows)/n*100:.1f}%")
    L.append("")
    L.append("축1 혼동표 (행=정답, 열=판정)")
    L.append("| 정답 | 있음 | 없음 | 어긋남 |")
    L.append("|---|---|---|---|")
    for g in B:
        L.append(f"| {g} | " + " | ".join(str(bconf[g][p]) for p in B) + " |")
    L.append("")
    if both:
        L.append(f"축2 조건표시 — 양쪽 '있음' {len(both)}개 중 일치 {sum(gc==pc for gc,pc in both)}개"
                 f" ({sum(gc==pc for gc,pc in both)/len(both)*100:.1f}%)")
        if c_gold:
            L.append(f"  재현율 {c_hit}/{c_gold} = {c_hit/c_gold*100:.1f}%"
                     + (f", 정밀도 {c_hit}/{c_pred} = {c_hit/c_pred*100:.1f}%" if c_pred else ", 정밀도 — 예측 0건"))
    L.append("")
    # 축1 기준으로 센다. status 문자열("자료 부족")과 basis 값("없음")을 섞으면 0건으로 잘못 나온다.
    over = [k for (g, p, k) in rows if axes(g)[0] == "없음" and axes(p)[0] == "있음"]
    under = [k for (g, p, k) in rows if axes(g)[0] == "있음" and axes(p)[0] == "없음"]
    L.append(f"설명 없는데 있다고 본 건(과대) {len(over)}개 {over}")
    L.append(f"설명 있는데 못 찾은 건(보수) {len(under)}개 {under}")
    L.append("")
    L.append("불일치 목록")
    for g, p, k in rows:
        if g != p:
            L.append(f"- {k}: 정답 {g} / 판정 {p}")
    txt = "\n".join(L)
    print(txt)
    if a.out:
        Path(a.out).write_text(txt + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
