"""2026-10-02 회사 설명의 종류 2차 — 회사가 공개한 공식 자료(제품 페이지의 누락 구절, 삼성닷컴 FAQ, 삼성 뉴스룸,
dyson.com·ecovacs.com·mova.tech 영문 공식 페이지, 로보락 공식 블로그)를 직접 확인해 근거·분류를 보강한다.
언론 기사·블로그·판매처 자료는 쓰지 않았다. 1세대(2024) 제품에 대한 설명은 2026년형에 소급 적용하지 않고 메모에만 남긴다.

  python eval/basis_round2.py DB경로 ...   (백업 *_before_basis2.sqlite3)
"""
import json, shutil, sqlite3, sys
from datetime import datetime

TODAY = "2026-10-02"
NOTE = f"공식 자료 추가 확인({TODAY})"

# 새로 붙이는 공식 자료 문서. (product_id, kind, title, url, [문장...])
DOCS = {
    4: [("공식 자료", "삼성전자 뉴스룸 '2026년형 비스포크 AI 스팀 로봇청소기 출시'(2026-02-11)",
         "https://news.samsung.com/kr/삼성전자-2026년형-비스포크-ai-스팀-로봇청소기-출시",
         ["AI 사물·공간 인식 기능도 진화했다. 제품 전면에 탑재된 RGB(Red, Green, Blue) 카메라 센서와 적외선(IR) LED를 통해 유색 액체는 물론 물처럼 투명한 액체까지 회피하거나 집중 청소할 수 있도록 업그레이드됐다."]),
        ("공식 자료", "삼성닷컴 로봇청소기 FAQ", "https://www.samsung.com/sec/home-appliances/faq-robot-vacuum-cleaners",
         ["AI 사물 인식으로 38개군 121종의 객체를 인식하고 회피하여 효율적인 청소를 제공합니다.",
          "거실과 주방 등 맵핑된 공간을 자동으로 분류하고 각 영역에 맞는 이름도 추천하여 보다 효율적으로 청소 구역을 관리하게 해줍니다.",
          "AI 바닥 인식 기능으로 바닥과 카펫을 알아서 구분해 최적의 청소 방법을 실행합니다."])],
    11: [("공식 자료", "삼성닷컴 로봇청소기 FAQ", "https://www.samsung.com/sec/home-appliances/faq-robot-vacuum-cleaners",
          ["부재 감지 청소 기능은 Wi-Fi 채널 상태 정보를 사용하여 집안에 사람이 없는지 감지하고 아무도 없을 때 알아서 청소를 시작합니다.",
           "빅스비와 자연스럽게 대화하며 편리하게 사용해 보세요. 날씨 정보와 같은 일상적인 대화부터 '집이 너무 더러워!'와 같은 자연스러운 대화로 청소를 지시할 수 있습니다."])],
    5: [("공식 자료", "LG전자 제품 페이지 추가 확인(유의사항·기능 설명)",
         "https://www.lge.co.kr/product/vacuum-cleaners/n95tho?modelId=MD10730837&pdpType=PURCHASE",
         ["헤매거나 바퀴가 들려 구속되었던 공간은 '고립 위험 영역'으로 인식하고 다음 청소에는 이를 회피하여 청소합니다.",
          "총 8종의 정밀 센서가 장애물, 벽면, 공간의 높낮이 등을 정밀하게 인식해 더욱 안정적이고 꼼꼼하게 청소합니다. 라이다 센서, 라이다 범퍼 센서, 카메라 센서, 3D 센서, 측면 센서, 범퍼 센서, 낭떠러지 센서, 카펫 감지용 초음파 센서",
          "감지하는 오염물은 4 x 4㎠ ~ 12 x 12㎠의 크기의 믹스 커피, 에스프레소, 초콜렛, 간장, 딸기잼, 땅콩잼과 같은 불투명한 유색의 고체 상태 오염물",
          "LG ThinQ 앱 내 'AI 인식 및 회피'에서 '장애물 및 오염 사진'을 설정하면 오염 청소 전후 사진을 촬영합니다. 서버에 저장된 사진은 3일 후 자동으로 삭제",
          "전방 카메라로 로봇청소기 전면 약 15cm 지점 이후부터, 전방 약 50cm × 50cm 영역에서 사물을 인식"])],
    6: [("공식 자료", "로보락 공식 블로그 'S10 MaxV Ultra'(2026-02-28)", "https://kr.roborock.com/blogs/roborock-kr/roborock-s10-maxv-ultra",
         ["3중 구조광과 RGB 카메라, VertiBeam™ 측면 구조광을 통해 300개 이상의 물체 유형을 인식하며, 케이블이나 의자 다리처럼 얇고 낮은 장애물까지 정밀하게 감지해 보다 안정적인 주행을 지원합니다."])],
    7: [("공식 자료", "드리미 X60 시리즈 공식 페이지 추가 확인(핵심기술)", "https://kr.dreametech.com/promotion/x60_series",
         ["AI 강화 OmniSight™ 시스템 블루라이트 광학 스캔 & 듀얼 광각 고정밀 카메라",
          "어두운 공간 속 숨어있는 미세먼지, 반려동물 털, 투명한 액체까지 인식"])],
    8: [("공식 자료", "MOVA 글로벌 공식 제품 페이지(영문)", "https://www.mova.tech/products/robot-vacuum-p70-pro-ultra",
         ["AI recognizes over 280 obstacles* and adapts to your unique items through custom app inputs*. (AI Vision Personalized Cleaning)",
          "An ultrasonic sensor detects carpets of varying pile heights and textures.",
          "Pet Care Customization detects pets and pet waste with up to 99.9%* accuracy. *99.9%: Based on tests in our in-house lab. *This feature will be available via OTA update"])],
    9: [("공식 자료", "다이슨 국문 제품 페이지 추가 확인", "https://www.dyson.co.kr/spot-scrub-ai-black",
         ["HD 카메라 + 얼룩 식별 기술 - 카메라로 표면을 확인하고 가정에서 발견되는 얼룩을 식별하며 흡입력을 스마트하게 조절 및 청소합니다.",
          "사물 인식 목적으로만 이미지를 캡처하며, 사람이나 얼굴 인식 기능은 없습니다."]),
        ("공식 자료", "다이슨 글로벌 공식 제품 페이지(영문)", "https://www.dyson.com/vacuum-cleaners/robot/spot-scrub-ai/black",
         ["compare its HD image of the stain with a memory bank of nearly 10 million annotated images of common household dirt, stains and spills",
          "While our robot is removing the stain, it uses machine learning and its HD camera to re-scan the area to double-check",
          "Samples its environment 7 times per second with Ai systems trained on hundreds of household objects"])],
    13: [("공식 자료", "에코백스 공식 제품 페이지 추가 확인(영문)", "https://www.ecovacs.com/kr/deebot-robotic-vacuum-cleaner/deebot-t90-pro-omni-auto-water-refill-and-drain-white",
          ["AIVI 3D 4.0 Omni-Approach Technology, powered by the VLM model and deep learning neural networks, delivers precise object recognition and instant contour detection. The front structured light and TruEdge 3D Edge Sensor work seamlessly to enable close-edge cleaning while maintaining safe contact.",
           "Obstacle Avoidance: Structured light, RGB AI+ Supplementary Light"])],
}

# 문구별 변경. key=(pid, claim_id). 값: basis, (선택) status, conditions, evidence=[(doc_key, chunk_idx)] — doc_key는
# 'new:<title 앞 6글자>' 또는 ('doc', doc_id, chunk). 기존 evidence는 유지하고 덧붙인다.
CLAIMS = {
    # 삼성 울트라
    (4, "c3"): dict(basis="vision", evidence=[("doc", 6, 43), ("new", "삼성전자 뉴스룸", 0)],
                    note="RGB 카메라로 사물을 인식한다는 설명(판매페이지·뉴스룸). 학습·모델 설명은 2026년형 공식 자료에 없음. 1세대(2024) 뉴스룸에 '170만 개 사물 데이터 DNN' 언급이 있으나 이 모델에 대한 문장이 아니라 근거로 쓰지 않음."),
    (4, "c7"): dict(basis="none", evidence=[("new", "삼성닷컴", 1)]),
    (4, "c9"): dict(basis="none", evidence=[("new", "삼성닷컴", 2)],
                    note="바닥·카펫 구분 방식은 2026년형 공식 자료에 없음. 1세대(2024) 분해기 기사에 초음파·가속도·자이로 센서 언급이 있으나 이 모델 문장이 아니라 쓰지 않음."),
    # 삼성 스팀
    (11, "c7"): dict(basis="sensor", evidence=[("new", "삼성닷컴", 0)]),
    (11, "c9"): dict(basis="none", evidence=[("new", "삼성닷컴", 1)]),
    # LG
    (5, "c3"): dict(basis="sensor", evidence=[("new", "LG전자 제품", 0)],
                    note="'AI 에지'는 바퀴 들림·구속 경험을 '고립 위험 영역'으로 기록해 다음 청소에서 피하는 규칙 기반 설명. 학습·카메라 언급 없음."),
    (5, "c7"): dict(basis="sensor", evidence=[("new", "LG전자 제품", 1)]),
    (5, "c5"): dict(basis="sensor", status="근거 확인", evidence=[("new", "LG전자 제품", 0)],
                    conditions="", note="제품 페이지 유의사항에서 '고립 위험 영역' 인식 방식(바퀴 들림·구속 경험 기록)을 확인."),
    (5, "c1"): dict(basis="vision", status="조건 확인", evidence=[("new", "LG전자 제품", 2), ("new", "LG전자 제품", 3)],
                    conditions="감지하는 오염물은 4×4㎠에서 12×12㎠ 크기의 불투명한 유색 고체 상태(믹스 커피, 간장, 잼 자국 등)예요. 오염 청소 전후 사진을 찍도록 설정하면 사진이 서버에 저장되고 3일 뒤 지워져요.",
                    note="제품 페이지 유의사항에서 감지 범위와 촬영 방식을 확인. 카메라 촬영 기반이나 학습 언급은 없음."),
    (5, "c2"): dict(basis="vision", status="조건 확인", evidence=[("new", "LG전자 제품", 2)],
                    conditions="마른 얼룩으로 인식하는 대상은 4×4㎠에서 12×12㎠ 크기의 불투명한 유색 고체 상태 오염물이에요.",
                    note="제품 페이지 유의사항에서 감지 범위를 확인."),
    # 로보락
    (6, "c2"): dict(basis="vision", evidence=[("new", "로보락 공식", 0)],
                    note="RGB 카메라와 구조광으로 300종 이상을 인식한다는 설명. 신경망·학습 데이터 언급은 공식 자료에 없음."),
    (6, "c3"): dict(basis="sensor"),
    # 드리미
    (7, "c2"): dict(basis="sensor"),
    (7, "c3"): dict(basis="vision", status="근거 확인", evidence=[("new", "드리미 X60", 0), ("new", "드리미 X60", 1)],
                    note="같은 페이지 '핵심기술'에 블루라이트 광학 스캔과 듀얼 광각 카메라로 먼지·털·액체를 인식한다는 설명이 있음."),
    (7, "c4"): dict(basis="vision", status="근거 확인", evidence=[("new", "드리미 X60", 0), ("new", "드리미 X60", 1)],
                    note="같은 페이지 '핵심기술'에 블루라이트 광학 스캔과 듀얼 광각 카메라로 먼지·털·액체를 인식한다는 설명이 있음."),
    (7, "c6"): dict(basis="none"),
    # 모바
    (8, "c3"): dict(basis="vision", evidence=[("doc", 14, 0), ("new", "MOVA 글로벌", 0)],
                    note="국문 페이지 'RGB AI 카메라', 영문 공식 페이지 'AI Vision'. 학습·모델 설명은 없음. 280종은 자사 실험실 데이터 기준."),
    (8, "c4"): dict(basis="sensor", evidence=[("new", "MOVA 글로벌", 1)]),
    (8, "c5"): dict(basis="none", evidence=[("new", "MOVA 글로벌", 2)]),
    # 다이슨
    (9, "c2"): dict(basis="learn", status="근거 확인", evidence=[("new", "다이슨 국문", 0), ("new", "다이슨 글로벌", 0), ("new", "다이슨 글로벌", 1)],
                    note="국문 페이지는 'HD 카메라 + 얼룩 식별 기술'까지만 설명. 다이슨 글로벌 공식 페이지(영문)에 약 1천만 장의 주석 이미지와 머신러닝으로 얼룩을 식별한다고 적혀 있음."),
    (9, "c3"): dict(basis="sensor", evidence=[("new", "다이슨 글로벌", 2)]),
    # 에코백스
    (13, "c1"): dict(basis="learn", status="근거 확인", evidence=[("new", "에코백스 공식", 0), ("new", "에코백스 공식", 1)],
                     note="공식 제품 페이지에 VLM 모델과 딥러닝 신경망, 전방 구조광으로 사물을 인식한다고 적혀 있음(영문)."),
    (13, "c2"): dict(basis="none"),
}

# 항목 보강
ITEMS = {
    (5, "conditions"): dict(status="조건 확인",
                            summary="AI 오염 인식이 감지하는 오염물은 4×4㎠에서 12×12㎠ 크기의 불투명한 유색 고체 상태(믹스 커피, 간장, 잼 자국 등)예요. 사물 인식은 전방 카메라로 앞쪽 약 15cm 너머 50×50cm 범위에서만 돼요.",
                            evidence=[("new", "LG전자 제품", 2), ("new", "LG전자 제품", 4)]),
    (5, "data"): dict(summary="LG Shield로 데이터 보안을 관리하고 개인정보보호위원회 PbD 인증을 받았다고 해요. 앱에서 '장애물 및 오염 사진'을 켜면 청소 전후 사진을 찍어 서버에 저장하고 3일 뒤 자동으로 지워요. 그 밖에 어떤 데이터를 어디서 처리하는지는 나와 있지 않아요.",
                     evidence=[("new", "LG전자 제품", 3)]),
    (9, "data"): dict(evidence=[("new", "다이슨 국문", 1)]),
}


# 쉬운 말 갱신(설명이 늘어난 카드)
EASY = {
    5: {"headline": "AI로 얼룩과 위험한 곳을 알아본다고 적혀 있어요. 다섯 문구 모두 회사 설명이 있어요.",
        "evidence": "5개 문구 모두 회사 설명이 있어요. 설명은 카메라와 센서 이야기이고, 학습 이야기는 없어요.",
        "conditions": "얼룩은 4~12cm 크기의 진한 색 마른 얼룩만 알아봐요. 물건은 앞쪽 50cm 안에서만 알아봐요.",
        "data": "LG Shield로 정보를 지킨다고 해요. 사진 찍기를 켜면 청소 전후 사진이 서버에 3일 동안 저장돼요."},
    7: {"evidence": "4개 문구 중 3개는 회사 설명이 있어요. 카펫 기능은 'AI'라고 했지만 직접 설정해야 한다고 적혀 있어요."},
    9: {"headline": "AI로 얼룩을 찾아 청소한다고 적혀 있어요. 1천만 장 가까운 사진으로 학습했다고 해요.",
        "evidence": "2개 문구 모두 회사 설명이 있어요. 얼룩 알아보기는 사진 1천만 장으로 학습했다고 영문 페이지에 적혀 있어요."},
    13: {"headline": "AI로 장애물과 얼룩을 알아본다고 적혀 있어요. 설명이 영어로만 되어 있어요.",
         "evidence": "3개 문구 중 2개는 회사 설명이 있어요. 장애물 알아보기는 딥러닝 신경망을 쓴다고 적혀 있어요."},
}


def apply(db: str) -> dict:
    shutil.copy(db, db.replace(".sqlite3", "_before_basis2.sqlite3"))
    c = sqlite3.connect(db)
    stats = {"docs": 0, "claims": 0, "items": 0}
    newdoc_ids: dict[tuple[int, str], int] = {}
    now = datetime.now().isoformat(timespec="seconds")
    for pid, docs in DOCS.items():
        if not c.execute("select 1 from products where id=?", (pid,)).fetchone():
            continue
        for kind, title, url, sents in docs:
            row = c.execute("select id from documents where product_id=? and title=?", (pid, title)).fetchone()
            if row:
                did = row[0]
            else:
                cur = c.execute("insert into documents(product_id,kind,title,url,fetched_at,text,chunks_json) values(?,?,?,?,?,?,?)",
                                (pid, kind, title, url, now, "\n".join(sents), json.dumps(sents, ensure_ascii=False)))
                did = cur.lastrowid; stats["docs"] += 1
            newdoc_ids[(pid, title)] = did

    def resolve(pid, ref):
        if ref[0] == "doc":
            _, did, ch = ref
            chunks = json.loads(c.execute("select chunks_json from documents where id=?", (did,)).fetchone()[0])
            kind = c.execute("select kind from documents where id=?", (did,)).fetchone()[0]
            return {"doc_id": did, "chunk": ch, "quote": chunks[ch], "kind": kind}
        _, key, ch = ref
        did = next(v for (p, t), v in newdoc_ids.items() if p == pid and t.startswith(key))
        chunks = json.loads(c.execute("select chunks_json from documents where id=?", (did,)).fetchone()[0])
        return {"doc_id": did, "chunk": ch, "quote": chunks[ch], "kind": "공식 자료"}

    for pid, in c.execute("select product_id from cards"):
        d = json.loads(c.execute("select card_json from cards where product_id=?", (pid,)).fetchone()[0])
        changed = False
        for cl in d["claims"]:
            spec = CLAIMS.get((pid, cl["id"]))
            if not spec:
                continue
            cl["basis_kind"] = spec["basis"]
            if "status" in spec:
                cl["reviewer_status"] = spec["status"]
            if "conditions" in spec:
                cl["conditions"] = spec["conditions"]
            for ref in spec.get("evidence", []):
                ev = resolve(pid, ref)
                if not any(e.get("doc_id") == ev["doc_id"] and e.get("chunk") == ev["chunk"] for e in cl.get("evidence", [])):
                    cl.setdefault("evidence", []).append(ev)
            if spec.get("note"):
                cl["reviewer_note"] = (cl.get("reviewer_note", "") + " " if cl.get("reviewer_note") else "") + f"{NOTE}: {spec['note']}"
            changed = True; stats["claims"] += 1
        for key, spec in ITEMS.items():
            if key[0] != pid:
                continue
            it = d["items"][key[1]]
            if "summary" in spec:
                it["summary"] = spec["summary"]
            if "status" in spec:
                it["status"] = spec["status"]
            for ref in spec.get("evidence", []):
                ev = resolve(pid, ref)
                if not any(e.get("doc_id") == ev["doc_id"] and e.get("chunk") == ev["chunk"] for e in it.get("evidence", [])):
                    it.setdefault("evidence", []).append(ev)
            changed = True; stats["items"] += 1
        if pid in EASY:
            for k, v in EASY[pid].items():
                if k == "headline":
                    d["easy"]["headline"] = v
                else:
                    d["easy"]["items"][k] = v
            changed = True
        if changed:
            # sources 목록에 새 문서 반영
            have = {s.get("doc_id") for s in d.get("sources", [])}
            for (p, _t), did in newdoc_ids.items():
                if p == pid and did not in have:
                    kind, title, url, cj = c.execute("select kind,title,url,chunks_json from documents where id=?", (did,)).fetchone()
                    d.setdefault("sources", []).append({"doc_id": did, "kind": kind, "title": title, "url": url, "n_chunks": len(json.loads(cj))})
                    have.add(did)
            c.execute("update cards set card_json=? where product_id=?", (json.dumps(d, ensure_ascii=False), pid))
    c.commit()
    stats["integrity"] = c.execute("pragma integrity_check").fetchone()[0]
    return stats


if __name__ == "__main__":
    for db in sys.argv[1:]:
        print(db, apply(db))
