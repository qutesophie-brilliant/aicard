"""2차 카드 29장을 독립 라벨(review_round2_labels.csv)로 채점한다. 개발용·시험용을 나눠 보고한다.

  python eval/round2_heldout.py eval/round2_results_v6.json --out eval/result_heldout.md

라벨은 라벨 당시 카드의 문구에 붙어 있으므로, 새 카드 문구와는 글자쌍 유사도(eval/round2.py same)로 짝을 맞춘다.
짝이 없는 새 문구는 판정 지표에서 빠지고 '라벨 없는 문구' 수로 따로 보고한다.
"""
import argparse
import csv
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from round2 import same  # noqa: E402

POS = {"근거 확인", "조건 확인"}
S = ["근거 확인", "조건 확인", "자료 부족", "추가 확인 필요"]


def score(rows: list[tuple[str, str]]) -> dict:
    n = len(rows)
    conf: dict[str, Counter] = defaultdict(Counter)
    for g, p in rows:
        conf[g][p] += 1
    ok4 = sum(g == p for g, p in rows)
    ok2 = sum((g in POS) == (p in POS) for g, p in rows)
    return {"n": n, "ok4": ok4, "ok2": ok2, "conf": conf,
            "unsup": sum(g == "자료 부족" and p in POS for g, p in rows),
            "missed": sum(g in POS and p == "자료 부족" for g, p in rows),
            "mm_t": sum(g == "추가 확인 필요" for g, p in rows),
            "mm_h": sum(g == p == "추가 확인 필요" for g, p in rows),
            "mm_fp": sum(p == "추가 확인 필요" and g != p for g, p in rows)}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("results")
    ap.add_argument("--labels", default=str(ROOT / "review_round2_labels.csv"))
    ap.add_argument("--split", default=str(ROOT / "round2_split.json"))
    ap.add_argument("--out", default=str(ROOT / "result_heldout.md"))
    a = ap.parse_args()
    res = json.load(open(a.results, encoding="utf-8"))
    split = json.load(open(a.split, encoding="utf-8"))
    labels: dict[str, list[dict]] = defaultdict(list)
    for r in csv.DictReader(open(a.labels, encoding="utf-8-sig")):
        labels[r["slug"]].append(r)

    out = {"dev": {"pairs": [], "pred": 0, "pred_inc": 0, "pred_exc": 0, "unlabeled": 0, "gold_inc": 0, "gold_hit": 0},
           "test": {"pairs": [], "pred": 0, "pred_inc": 0, "pred_exc": 0, "unlabeled": 0, "gold_inc": 0, "gold_hit": 0}}
    for slug, info in res["pushed"].items():
        part = "test" if slug in split["test"] else "dev"
        o = out[part]
        ex = res["exports"].get(str(info["pid"]))
        if not ex or not ex.get("card"):
            continue
        lab = labels.get(slug, [])
        inc = [x for x in lab if x["decision"] == "include"]
        o["gold_inc"] += len(inc)
        hit_gold: set[int] = set()
        for c in ex["card"]["claims"]:
            o["pred"] += 1
            m = next((x for x in lab if same(c["text"], x["claim_text"])), None)
            if m is None:
                o["unlabeled"] += 1
                continue
            if m["decision"] != "include":
                o["pred_exc"] += 1
                continue
            o["pred_inc"] += 1
            k = inc.index(m)
            if k in hit_gold:
                continue
            hit_gold.add(k)
            o["pairs"].append((m["gold_status"], c["status"]))
        o["gold_hit"] += len(hit_gold)

    lines = ["# 확장 평가 (2차 카드 29장, 독립 라벨 기준)", "",
             f"원본: {a.results}. 라벨: {a.labels} (Claude 독립 라벨 + 갈린 건 3차 판정, 소민 확인 전).",
             "개발용 20개 제품의 오답만 보고 규칙을 고쳤고, 시험용 9개 제품은 규칙을 고칠 때 보지 않았다.", ""]
    for part, title in (("test", "시험용 9개 제품 (보고용)"), ("dev", "개발용 20개 제품")):
        o = out[part]
        s = score(o["pairs"])
        labeled = o["pred_inc"] + o["pred_exc"]
        lines += [f"## {title}", "",
                  "| 지표 | 값 |", "|---|---|",
                  f"| 뽑은 문구 | {o['pred']} (라벨 있는 문구 {labeled}, 라벨 없는 새 문구 {o['unlabeled']}) |",
                  f"| 추출 정밀도(라벨 있는 문구 중 표시 문구) | {100 * o['pred_inc'] / max(1, labeled):.1f}% ({o['pred_inc']}/{labeled}) |",
                  f"| 라벨 표시 문구 중 다시 찾은 비율 | {100 * o['gold_hit'] / max(1, o['gold_inc']):.1f}% ({o['gold_hit']}/{o['gold_inc']}) |",
                  f"| 4분류 정확도 | {100 * s['ok4'] / max(1, s['n']):.1f}% ({s['ok4']}/{s['n']}) |",
                  f"| 2분류 정확도(근거 있음/없음) | {100 * s['ok2'] / max(1, s['n']):.1f}% ({s['ok2']}/{s['n']}) |",
                  f"| 근거 없이 긍정 판정 | {s['unsup']} |",
                  f"| 근거가 있는데 '자료 부족' | {s['missed']} |",
                  f"| 어긋남 탐지 / 오탐 | {s['mm_h']}/{s['mm_t']} / {s['mm_fp']} |", "",
                  "| 사람\\AI | " + " | ".join(S) + " |", "|---|---|---|---|---|"]
        for g in S:
            lines.append(f"| {g} | " + " | ".join(str(s['conf'][g][p]) for p in S) + " |")
        lines.append("")
    Path(a.out).write_text("\n".join(lines), encoding="utf-8")
    print("\n".join(lines))


if __name__ == "__main__":
    main()
