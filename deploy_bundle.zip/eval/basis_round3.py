"""2026-10-02 국내/해외 자료 구분 — 해외 영문 공식 페이지에서 가져온 문서를 '해외 공식 자료'로 표시하고,
그 자료로만 달라지는 설명 종류는 basis_kind_global 에 따로 둔다. 판정(status)과 basis_kind 는 국내 자료 기준으로 되돌린다.
  python eval/basis_round3.py DB경로 ...   (백업 *_before_basis3.sqlite3)"""
import json, shutil, sqlite3, sys

GLOBAL_TITLES = ["다이슨 글로벌 공식 제품 페이지(영문)", "MOVA 글로벌 공식 제품 페이지(영문)"]
# (pid, claim) -> (basis_kr, basis_global or None, note)
FIX = {
    (9, "c2"): ("vision", "learn", "국내 페이지 기준 'HD 카메라 + 얼룩 식별 기술'(카메라 인식). 학습(약 1천만 장 주석 이미지·머신러닝) 설명은 다이슨 글로벌 영문 페이지에만 있어 해외 자료로 구분."),
    (8, "c3"): ("vision", None, "국내 페이지 'RGB AI 카메라' 기준 카메라 인식. 영문 페이지 'AI Vision'도 같은 분류."),
    (8, "c4"): ("sensor", None, None),
    (8, "c5"): ("none", None, None),
}


def apply(db: str) -> dict:
    shutil.copy(db, db.replace(".sqlite3", "_before_basis3.sqlite3"))
    c = sqlite3.connect(db)
    gids = set()
    for t in GLOBAL_TITLES:
        for (did,) in c.execute("select id from documents where title=?", (t,)):
            c.execute("update documents set kind='해외 공식 자료' where id=?", (did,)); gids.add(did)
    n = 0
    for pid, in c.execute("select product_id from cards"):
        d = json.loads(c.execute("select card_json from cards where product_id=?", (pid,)).fetchone()[0])
        changed = False
        for cl in d["claims"]:
            for e in cl.get("evidence", []):
                if e.get("doc_id") in gids and e.get("kind") != "해외 공식 자료":
                    e["kind"] = "해외 공식 자료"; e["scope"] = "global"; changed = True
            spec = FIX.get((pid, cl["id"]))
            if spec:
                kr, gl, note = spec
                cl["basis_kind"] = kr
                cl["basis_kind_global"] = gl
                if note:
                    cl["reviewer_note"] = (cl.get("reviewer_note", "") + " 국내/해외 구분(2026-10-02): " + note).strip()
                changed = True; n += 1
        for s in d.get("sources", []):
            if s.get("doc_id") in gids:
                s["kind"] = "해외 공식 자료"; changed = True
        for k, it in d["items"].items():
            for e in it.get("evidence", []):
                if e.get("doc_id") in gids and e.get("kind") != "해외 공식 자료":
                    e["kind"] = "해외 공식 자료"; e["scope"] = "global"; changed = True
        if pid == 9:
            d["easy"]["headline"] = "AI로 얼룩을 찾아 청소한다고 적혀 있어요. 국문 페이지는 카메라로 얼룩을 알아본다고만 해요."
            d["easy"]["items"]["evidence"] = "2개 문구 모두 회사 설명이 있어요. 사진 1천만 장으로 학습했다는 말은 영문 페이지에만 있어요."
            changed = True
        if changed:
            c.execute("update cards set card_json=? where product_id=?", (json.dumps(d, ensure_ascii=False), pid))
    c.commit()
    return {"global_docs": len(gids), "claims": n, "integrity": c.execute("pragma integrity_check").fetchone()[0]}


if __name__ == "__main__":
    for db in sys.argv[1:]:
        print(db, apply(db))
