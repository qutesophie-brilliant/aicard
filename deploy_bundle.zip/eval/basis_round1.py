"""2026-10-02 회사 설명의 종류(basis_kind) 1차 초안 — 각주·근거 문장을 다시 읽고 매김. 소민 승인 전 초안.
   python eval/basis_round1.py DB경로  (백업 *_before_basis.sqlite3)"""
import json, shutil, sqlite3, sys

# learn=학습·모델 언급 / vision=카메라 인식 / sensor=센서·규칙 / none=작동 방식 설명 없음
BASIS = {
    (4, "c2"): "vision",   # RGB 카메라 + 적외선 LED로 액체 감지
    (4, "c3"): "none",     # 크기 한계·지원 모델만, 인식 방식 설명 없음
    (4, "c4"): "none",     # 오염 구역 정의만
    (4, "c5"): "none",
    (4, "c7"): "none",     # 인식 가능한 공간 범위만
    (4, "c8"): "sensor",   # dToF LiDAR 스캔
    (4, "c9"): "none",
    (5, "c3"): "vision",   # RGB 카메라와 센서 기반
    (5, "c7"): "sensor",   # 8종 정밀 센서
    (6, "c2"): "vision",   # 3중 구조광 + RGB 카메라
    (6, "c3"): "sensor",   # 구조광
    (6, "c6"): "none",     # 동작 설명만
    (7, "c2"): "sensor",   # 듀얼 레이저 센서
    (7, "c6"): "none",
    (8, "c3"): "none",     # 실험실 데이터 기준만
    (8, "c4"): "sensor",   # 초음파 센서
    (8, "c5"): "none",
    (9, "c3"): "sensor",   # 24개 센서 + 듀얼 레이저 LiDAR
    (11, "c2"): "sensor",  # LiDAR 스캔
    (11, "c4"): "sensor",  # 5개 센서
    (11, "c7"): "sensor",  # 와이파이 채널 상태 정보
    (11, "c9"): "none",    # 지원 언어·모델만
    (13, "c2"): "none",
}


def apply(db: str) -> int:
    shutil.copy(db, db.replace(".sqlite3", "_before_basis.sqlite3"))
    c = sqlite3.connect(db)
    n = 0
    for pid, in c.execute("select product_id from cards"):
        d = json.loads(c.execute("select card_json from cards where product_id=?", (pid,)).fetchone()[0])
        changed = False
        for cl in d["claims"]:
            k = BASIS.get((pid, cl["id"]))
            if k and cl.get("basis_kind") != k:
                cl["basis_kind"] = k; changed = True; n += 1
        if changed:
            c.execute("update cards set card_json=? where product_id=?", (json.dumps(d, ensure_ascii=False), pid))
    c.commit()
    print(c.execute("pragma integrity_check").fetchone()[0])
    return n


if __name__ == "__main__":
    for db in sys.argv[1:]:
        print(db, apply(db))
