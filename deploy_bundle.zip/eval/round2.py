"""2차 정확도 측정.

1차 정답 라벨(eval/review_round1_labels.csv)의 제품 10개를 개선된 파이프라인으로 다시 돌려(저장하지 않음)
추출 정밀도와 확인상태 정확도를 1차와 같은 방법으로 잰다.

사용법
  # Render 또는 로컬 서버(검토자 토큰 필요). LLM 호출 수 = 제품 수 × 2
  python eval/round2.py --base https://aicard-3b2h.onrender.com --token lucky7 --out eval/result_round2.md
  # 이미 받아 둔 JSON으로 다시 계산만
  python eval/round2.py --from-json eval/round2_cards.json --out eval/result_round2.md

측정 방법(1차와 동일)
  - 추출 정밀도: AI가 뽑은 문구 중 1차 라벨에서 '카드에 남김(include)'으로 판정된 문구와 같은 문장의 비율.
    같은 문장 판정은 글자쌍(bigram) 포함률 0.6 이상.
  - 확인상태 정확도: include 문구 가운데 AI가 다시 뽑은 것에 대해 AI status 와 gold_status 비교(4분류·2분류).
  - 재현율(참고): include 문구 37건 중 AI가 다시 뽑은 비율.
"""
import argparse
import csv
import json
import re
import sys
import time
from collections import Counter, defaultdict
from pathlib import Path

import httpx

ROOT = Path(__file__).resolve().parent
POSITIVE = {"근거 확인", "조건 확인"}
STATUSES = ["근거 확인", "조건 확인", "자료 부족", "추가 확인 필요"]


def bigrams(t: str) -> set[str]:
    t = re.sub(r"\W", "", t)
    return {t[i:i + 2] for i in range(len(t) - 1)}


def same(a: str, b: str) -> bool:
    x, y = bigrams(a), bigrams(b)
    return bool(x and y) and len(x & y) / min(len(x), len(y)) >= 0.6


def fetch(base: str, token: str, pids: list[int]) -> dict[int, dict]:
    out: dict[int, dict] = {}
    with httpx.Client(base_url=base, timeout=300, follow_redirects=False) as c:
        r = c.post("/review/login", data={"token": token})
        if r.status_code not in (302, 303):
            sys.exit(f"로그인 실패 {r.status_code}")
        for pid in pids:
            t0 = time.time()
            r = c.get(f"/review/{pid}/dryrun.json")
            if r.status_code != 200:
                print(f"  제품 {pid}: 실패 {r.status_code} {r.text[:120]}")
                continue
            data = r.json()
            out[pid] = data["card"]
            print(f"  제품 {pid}: 문구 {len(data['card']['claims'])}개, {data['meta'].get('provider')} {time.time() - t0:.0f}초")
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default="")
    ap.add_argument("--token", default="")
    ap.add_argument("--labels", default=str(ROOT / "review_round1_labels.csv"))
    ap.add_argument("--from-json", default="")
    ap.add_argument("--save-json", default=str(ROOT / "round2_cards.json"))
    ap.add_argument("--out", default="")
    args = ap.parse_args()

    rows = list(csv.DictReader(open(args.labels, encoding="utf-8-sig")))
    by_pid: dict[int, list[dict]] = defaultdict(list)
    for r in rows:
        by_pid[int(r["product_id"])].append(r)
    pids = sorted(by_pid)

    if args.from_json:
        cards = {int(k): v for k, v in json.load(open(args.from_json, encoding="utf-8")).items()}
    else:
        if not args.base or not args.token:
            sys.exit("--base 와 --token 이 필요합니다(또는 --from-json).")
        print(f"제품 {len(pids)}개, LLM 호출 {len(pids) * 2}회 예정")
        cards = fetch(args.base, args.token, pids)
        json.dump({str(k): v for k, v in cards.items()}, open(args.save_json, "w", encoding="utf-8"), ensure_ascii=False, indent=1)

    n_pred = n_pred_true = 0
    gold_inc = gold_hit = 0
    conf: dict[str, Counter] = defaultdict(Counter)
    n = ok4 = ok2 = 0
    unsupported = missed = 0
    mismatch_total = mismatch_hit = 0
    per: dict[int, list] = {}
    for pid in pids:
        card = cards.get(pid)
        if not card:
            continue
        labels = by_pid[pid]
        inc = [r for r in labels if r.get("decision", "").strip() == "include"]
        preds = card.get("claims", [])
        matched_gold: set[int] = set()
        pt = 0
        for p in preds:
            n_pred += 1
            hit = None
            for i, r in enumerate(inc):
                if same(p["text"], r["claim_text"]):
                    hit = i
                    break
            if hit is None:
                continue
            n_pred_true += 1
            pt += 1
            if hit in matched_gold:
                continue
            matched_gold.add(hit)
            gold = inc[hit]["gold_status"].strip()
            if gold not in STATUSES:
                continue
            pred = p.get("status")
            n += 1
            conf[gold][pred] += 1
            ok4 += pred == gold
            ok2 += (pred in POSITIVE) == (gold in POSITIVE)
            if gold == "자료 부족" and pred in POSITIVE:
                unsupported += 1
            if gold in POSITIVE and pred == "자료 부족":
                missed += 1
            if gold == "추가 확인 필요":
                mismatch_total += 1
                mismatch_hit += pred == "추가 확인 필요"
        gold_inc += len(inc)
        gold_hit += len(matched_gold)
        per[pid] = [labels[0]["product"], len(preds), pt, len(inc), len(matched_gold)]

    lines = ["# 2차 평가 결과", "",
             f"1차 정답 라벨(37건 포함, 23건 제외)의 제품 {len(per)}개를 개선한 파이프라인으로 다시 돌렸다. 저장하지 않은 AI 초안 기준이다.", "",
             "## 1. 문구 추출", "",
             "| 지표 | 1차 | 2차 |", "|---|---|---|",
             f"| AI가 뽑은 문구 | 60 | {n_pred} |",
             f"| 그중 실제 'AI' 표시 문구 | 37 | {n_pred_true} |",
             f"| 추출 정밀도 | 61.7% | {100 * n_pred_true / max(1, n_pred):.1f}% |",
             f"| 1차 표시 문구 37건 중 다시 찾은 비율(재현율) | — | {100 * gold_hit / max(1, gold_inc):.1f}% ({gold_hit}/{gold_inc}) |", "",
             "## 2. 확인상태 판정 (다시 찾은 표시 문구)", "",
             "| 지표 | 1차 | 2차 |", "|---|---|---|",
             f"| 4분류 정확도 | 62.2% | {100 * ok4 / max(1, n):.1f}% ({ok4}/{n}) |",
             f"| 2분류 정확도(근거 있음/없음) | 67.6% | {100 * ok2 / max(1, n):.1f}% ({ok2}/{n}) |",
             f"| 근거 없이 긍정 판정 | 2 | {unsupported} |",
             f"| 근거가 있는데 '자료 부족' | 8 | {missed} |",
             f"| 어긋남('추가 확인 필요') 탐지 | 0/3 | {mismatch_hit}/{mismatch_total} |", "",
             "혼동행렬(행: 사람 판정, 열: AI 판정)", "",
             "| | " + " | ".join(STATUSES) + " |", "|---" * (len(STATUSES) + 1) + "|"]
    for g in STATUSES:
        lines.append(f"| {g} | " + " | ".join(str(conf[g][p]) for p in STATUSES) + " |")
    lines += ["", "## 3. 제품별", "", "| 제품 | AI가 뽑음 | 그중 표시 문구 | 1차 표시 문구 | 다시 찾음 |", "|---|---|---|---|---|"]
    for pid, (name, a, b, c, d) in per.items():
        lines.append(f"| {name} | {a} | {b} | {c} | {d} |")
    report = "\n".join(lines)
    print(report)
    if args.out:
        Path(args.out).write_text(report + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
