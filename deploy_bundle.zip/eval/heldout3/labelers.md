# 3차 정답 라벨 — 라벨러 구성과 절차

## 구성
- 독립 라벨러 3인. 본 자료와 발표·보고 전반에서 **A·B·C로만 표기**한다. 라벨러 본인들에게 익명 처리를 약속했으므로 실명·소속·연령은 어디에도 적지 않는다.
- 세 사람은 서로의 판정을 보지 못했고, 파이프라인 판정도 보지 못했다.

## 일자
- 2026년 10월 3일. 세 사람 모두 같은 날 제출함.

## 받은 자료
- 코드북 — `eval/codebook/labeling_guide_v1_4status.md` (확인상태 4종을 한 줄로 고르던 판)
- 문구와 판매페이지 원문 — 파이프라인 판정을 뺀 사본

## 산출물
- `labels_A.csv` · `labels_B.csv` · `labels_C.csv` — 각 37건
- `disputes.json` — 셋이 갈린 건
- `adjudicated.csv` — 출처를 가린 3차 판정
- `gold_final.json` — 확정된 정답 37건(include 21, exclude 16)

## 일치도
- Fleiss κ 0.77(추출 여부)·0.79(확인상태). Landis–Koch 기준으로 '상당한 일치' 구간.
- 계산은 `eval/kappa.py`. 세 파일 모두에 있는 문구만 쓴다.

## 다음 회차에 바뀌는 것
- 새 품목 12개(문구 72건)는 두 축 코드북 `eval/codebook/labeling_guide_v2_2axis.md`로 매긴다.
  확인상태를 한 줄로 고르지 않고 근거상태(있음·없음·어긋남)와 조건표시(예·아니오)를 따로 적는다.
- 자료는 `/review/blind` 화면, 표는 `/review/blind/labels.csv`.
