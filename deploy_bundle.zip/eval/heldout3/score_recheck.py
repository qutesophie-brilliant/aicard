import csv, json, sys
from collections import Counter, defaultdict
from pathlib import Path
sys.path.insert(0, 'eval')
from round2 import same

SLUG2PID = {'dm_x50_ultra':72,'ec_t30_pro_omni':73,'ec_x8_pro_omni':74,'lg_as235dwsa':75,
 'lg_n95thu':76,'nw_freo_x_ultra':77,'rr_qrevo_edge_2':78,'rr_s8_maxv_ultra':79,
 'ss_ap90h10198edd':80,'xm_purifier_4_pro':81,'xm_s20_plus':83}
POS={"근거 확인","조건 확인"}
def axes(s):
    if s=="추가 확인 필요": return "어긋남", False
    if s in POS: return "있음", s=="조건 확인"
    return "없음", False

gold=json.load(open('eval/heldout3/gold_final.json'))
text={}
for r in csv.DictReader(open('eval/heldout3/labels_A.csv',encoding='utf-8-sig')):
    text[f"{r['pid']}:{r['claim_id']}"]=r['claim_text']

new=json.load(open('/tmp/new11.json'))
rows=[]; unmatched_new=[]; unmatched_gold=[]
used=set()
for slug,claims in new.items():
    pid=SLUG2PID[slug]
    gk=[k for k in gold if k.startswith(f"{pid}:")]
    for c in claims:
        hit=None
        for k in gk:
            if k in used: continue
            if same(c['t'], text.get(k,'')): hit=k; break
        if hit is None:
            unmatched_new.append((slug,c['t'][:60])); continue
        used.add(hit)
        g=gold[hit]
        if g['decision']!='include': continue      # 라벨러가 제외한 문구는 채점 대상 아님
        rows.append((g['status'], c['s'], hit))
for k,v in gold.items():
    if k not in used and v['decision']=='include':
        unmatched_gold.append(k)

n=len(rows)
ok4=sum(g==p for g,p,_ in rows)
ok2=sum((g in POS)==(p in POS) for g,p,_ in rows)
ax=[(axes(g),axes(p)) for g,p,_ in rows]
b_ok=sum(ga==pa for (ga,_),(pa,_) in ax)
bconf=defaultdict(Counter)
for (ga,_),(pa,_) in ax: bconf[ga][pa]+=1
both=[(gc,pc) for (ga,gc),(pa,pc) in ax if ga==pa=="있음"]
print(f"채점 문구 {n}  (라벨 없는 새 문구 {len(unmatched_new)}, 짝 못 찾은 라벨 {len(unmatched_gold)})")
if n:
    print(f"축1 근거상태 정확도 {b_ok}/{n} = {b_ok/n*100:.1f}%")
    print(f"4분류(참고)     {ok4}/{n} = {ok4/n*100:.1f}%")
    print(f"2분류(설명 유무) {ok2}/{n} = {ok2/n*100:.1f}%")
    print("축1 혼동표 (행=정답):")
    for g in ["있음","없음","어긋남"]:
        print("  ",g, dict(bconf[g]))
    if both:
        hit=sum(gc and pc for gc,pc in both); gn=sum(gc for gc,_ in both); pn=sum(pc for _,pc in both)
        print(f"축2 조건표시 (양쪽 '있음' {len(both)}건): 일치 {sum(gc==pc for gc,pc in both)}, 정답 {gn}, 예측 {pn}, 교집합 {hit}")
    print("\n불일치:")
    for g,p,k in rows:
        if g!=p: print(f"  {k}: 정답 {g} / 판정 {p}")
print("\n라벨 없는 새 문구:", unmatched_new)
print("짝 못 찾은 라벨:", unmatched_gold)
