"""2026-10-02 국문 교정 2차 — 카드 데이터(조건·요약·쉬운 말)의 번역투·명사화를 손본다.
   python eval/humanize_round2.py DB경로   (백업: *_before_humanize2.sqlite3)"""
import json, shutil, sqlite3, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROWS = json.load(open(HERE.parent / "_workspace/2026-10-02-002/rows.json", encoding="utf-8"))
NEW = {int(k): v for k, v in json.load(open(HERE.parent / "_workspace/2026-10-02-002/changes.json", encoding="utf-8")).items()}


def apply(db: str) -> int:
    shutil.copy(db, db.replace(".sqlite3", "_before_humanize2.sqlite3"))
    c = sqlite3.connect(db)
    n = 0
    cards = {}
    for i, (pid, kind, key, sub, old) in enumerate(ROWS):
        if i not in NEW or NEW[i] == old:
            continue
        if pid not in cards:
            row = c.execute("select card_json from cards where product_id=?", (pid,)).fetchone()
            if not row:
                continue
            cards[pid] = json.loads(row[0])
        d = cards[pid]
        if kind == "claim":
            for cl in d["claims"]:
                if cl["id"] == key and cl.get("conditions") == old:
                    cl["conditions"] = NEW[i]; n += 1
        elif kind == "item" and d["items"].get(key, {}).get("summary") == old:
            d["items"][key]["summary"] = NEW[i]; n += 1
        elif kind == "easy" and key == "headline" and d["easy"].get("headline") == old:
            d["easy"]["headline"] = NEW[i]; n += 1
        elif kind == "easy" and key == "items" and d["easy"]["items"].get(sub) == old:
            d["easy"]["items"][sub] = NEW[i]; n += 1
    for pid, d in cards.items():
        c.execute("update cards set card_json=? where product_id=?", (json.dumps(d, ensure_ascii=False), pid))
    c.commit()
    print(c.execute("pragma integrity_check").fetchone()[0])
    return n


if __name__ == "__main__":
    for db in sys.argv[1:]:
        print(db, apply(db))
