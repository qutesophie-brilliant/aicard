"""서버에서 내려받은 round2_results.json 을 로컬 DB에 넣고, 2차 정확도 측정용 JSON을 만든다.

  python eval/round2_import.py <round2_results.json> --db data/aicard.sqlite3
  python eval/round2.py --from-json eval/round2_cards.json --out eval/result_round2.md
"""
import argparse
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


def remap(o, idmap):
    if isinstance(o, dict):
        if "doc_id" in o and o["doc_id"] in idmap:
            o["doc_id"] = idmap[o["doc_id"]]
        for v in o.values():
            remap(v, idmap)
    elif isinstance(o, list):
        for v in o:
            remap(v, idmap)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("results")
    ap.add_argument("--db", default=str(ROOT / "data" / "aicard.sqlite3"))
    ap.add_argument("--cards-out", default=str(ROOT / "eval" / "round2_cards.json"))
    ap.add_argument("--skip-import", action="store_true")
    a = ap.parse_args()
    os.environ["AICARD_DB"] = str(Path(a.db).resolve())
    from app import db  # noqa: E402

    rp = Path(a.results)
    if rp.is_dir():  # 서버에서 하나씩 받아 둔 export_slim.json 묶음 → results 형태로 합친다
        res = {"pushed": {}, "exports": {}, "dryrun": {}, "errors": {}}
        for f in sorted(rp.glob("*.json")):
            j = json.load(open(f, encoding="utf-8"))
            if "card" in j and "product" in j:
                pid = j["product"]["id"]
                res["pushed"][f.stem] = {"pid": pid}
                res["exports"][str(pid)] = j
            elif f.stem.startswith("dryrun_"):
                res["dryrun"][f.stem.split("_", 1)[1]] = j
    else:
        res = json.load(open(rp, encoding="utf-8"))
    if not a.skip_import:
        done_p = Path(a.results).with_suffix(".imported.json")
        done = json.load(open(done_p, encoding="utf-8")) if done_p.exists() else {}
        for slug, info in res["pushed"].items():
            if slug in done:
                continue
            ex = res["exports"].get(str(info["pid"]))
            if not ex or not ex.get("card"):
                print(f"  {slug}: 카드 없음, 건너뜀")
                continue
            p = ex["product"]
            new_pid = db.create_product(p["name"], p.get("maker", ""), p.get("model", ""), p.get("category", ""))
            idmap = {}
            for doc in ex["documents"]:
                chunks = doc.get("chunks")
                if chunks is None:  # 가벼운 내보내기: 서버와 같은 규칙으로 다시 나눈다(결정적이라 번호가 같다)
                    from app.pipeline.ingest import chunk_text
                    chunks = chunk_text(doc.get("text", ""), ocr=doc.get("title", "").startswith("상세 이미지"))
                idmap[doc["id"]] = db.add_document(new_pid, doc["kind"], doc["title"], doc.get("url", ""), doc.get("text", ""), chunks)
            card = ex["card"]
            remap(card, idmap)
            card["product_id"] = new_pid
            db.save_card(new_pid, card, ex.get("meta") or {})
            db.set_product_status(new_pid, "pending", p.get("reviewer_note") or "2차 수집 — 검토 대기")
            done[slug] = new_pid
            json.dump(done, open(done_p, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
            print(f"  {slug} → 로컬 제품 {new_pid} (문서 {len(ex['documents'])}, 문구 {len(card.get('claims', []))})")
        if res.get("errors"):
            print("서버 쪽 실패:", json.dumps(res["errors"], ensure_ascii=False)[:800])
    dry = {pid: v["card"] for pid, v in (res.get("dryrun") or {}).items()}
    if dry:
        json.dump(dry, open(a.cards_out, "w", encoding="utf-8"), ensure_ascii=False)
        print(f"dryrun 카드 {len(dry)}개 → {a.cards_out}  (다음: python eval/round2.py --from-json {a.cards_out} --out eval/result_round2.md)")


if __name__ == "__main__":
    main()
