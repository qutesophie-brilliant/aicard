"""새 품목(에어컨·세탁기) 12개 결과에서 ① 라벨러용 블라인드 자료와 ② 판정 예측을 따로 떼어 낸다.

  python eval/round4_blind.py eval/round4_results.json --out eval/heldout4

최종 정확도는 이 12개에서 한 번만 잰다. 그러므로 라벨러에게 가는 자료에는 파이프라인 판정이 한 글자도 없어야 한다.
  blind/<pid>.json        제품 정보 + 판매페이지 본문·각주 + 문구 목록(판정 없음)
  labels_template.csv     라벨러가 채우는 표(decision·basis·conditions_noted·gold_evidence_quote)
  pred.json               파이프라인 판정(채점할 때만 연다)
"""
import argparse
import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CONTROL = {"si_sma_c7800hs", "wn_wwd12gew"}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("results")
    ap.add_argument("--out", default=str(ROOT / "heldout4"))
    a = ap.parse_args()
    res = json.load(open(a.results, encoding="utf-8"))
    out = Path(a.out)
    (out / "blind").mkdir(parents=True, exist_ok=True)
    rows, pred, n_claim = [], {}, 0
    for slug, info in sorted(res["pushed"].items()):
        ex = res["exports"].get(str(info["pid"])) if isinstance(res.get("exports"), dict) else None
        if not ex or not ex.get("card"):
            print(f"  건너뜀 {slug}: 카드 없음")
            continue
        pid = info["pid"]
        claims = ex["card"].get("claims", [])
        blind = {"pid": pid, "slug": slug, "control": slug in CONTROL,
                 "product": {k: ex["product"].get(k) for k in ("name", "maker", "model", "category")},
                 "documents": [{"kind": d.get("kind"), "title": d.get("title"), "url": d.get("url"),
                                "text": d.get("text", "")} for d in ex.get("documents", [])],
                 "claims": [{"id": c.get("id"), "text": c.get("text")} for c in claims]}
        (out / "blind" / f"{pid}.json").write_text(json.dumps(blind, ensure_ascii=False, indent=1), encoding="utf-8")
        for c in claims:
            n_claim += 1
            rows.append({"pid": pid, "slug": slug, "product": ex["product"]["name"],
                         "control": "Y" if slug in CONTROL else "", "claim_id": c.get("id", ""),
                         "claim_text": c.get("text", ""), "decision": "", "basis": "",
                         "conditions_noted": "", "gold_evidence_quote": "", "labeler": "", "note": ""})
            pred[f"{pid}:{c.get('id')}"] = {"status": c.get("status", ""),
                                            "basis_state": c.get("basis_state", ""),
                                            "conditions_noted": bool(c.get("conditions_noted")),
                                            "evidence": [e.get("quote", "")[:200] for e in (c.get("evidence") or [])[:3]],
                                            "conditions": c.get("conditions", "")}
    with open(out / "labels_template.csv", "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    (out / "pred.json").write_text(json.dumps(pred, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"제품 {len(set(r['slug'] for r in rows))}개 · 문구 {n_claim}개 → {out}")
    print("라벨러에게는 blind/ 와 labels_template.csv 만 준다. pred.json 은 채점할 때 연다.")


if __name__ == "__main__":
    main()
