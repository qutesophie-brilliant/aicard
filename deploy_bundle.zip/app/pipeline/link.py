"""주장 ↔ 근거 연결과 4단계 확인상태 판정.

LLM 호출은 주장 전체를 한 번에 묶어서 보낸다(카드 한 장당 1회). 무료 등급 한도(하루 요청 수)를
아끼고 속도를 높이기 위해서다. 묶음 호출이 실패하면 주장별 규칙 판정으로 대신한다.
"""
import json
import re
from typing import Any

from . import llm
from .retrieve import ChunkIndex
from ..config import STATUSES

BATCH_PROMPT = """제품 판매페이지의 AI 표시 문구(주장)들과, 각 주장마다 각주·사양표·설명서·공식 자료에서 찾은 후보 문장들입니다.

각 주장에 대해 다음을 판정하세요.
- status: 다음 네 가지 중 하나
  * "근거 확인": 주장을 뒷받침하는 구체적 설명(작동 방식·사용 센서나 카메라·측정 방법·시험 기관·수치)이 후보에 있음
  * "조건 확인": 위 설명이 있고, 적용 조건이나 한계(환경·크기·조도·바닥 재질·지원 모델·사전 설정·인식 실패 사례·앱 설정 필요)도 후보에 적혀 있음.
    각주(※, *, 1) 같은 표시로 시작하는 문장)가 그 기능의 조건을 적고 있으면 그 자체가 근거이자 조건입니다.
  * "자료 부족": 후보가 주장을 되풀이하거나 광고 문구일 뿐, 작동 방식이나 조건이 없음
  * "추가 확인 필요": 주장과 후보가 서로 어긋남. 다음 중 하나라도 해당하면 반드시 이 값으로 둡니다.
    - 주장이 말하는 대상의 범위와 후보의 정의가 다름(예: 주장은 "액체와 고체", 각주는 "액체가 아닌 고체")
    - 주장은 자동·AI라고 하는데 후보는 사용자가 직접 설정해야 한다고 적음
    - 후보가 그 기능을 "업데이트로 제공 예정"이라고 적어 구매 시점에는 없음
    - 수치·개수·시간이 서로 다름, 또는 다른 모델(상위 모델)의 설명임을 각주가 밝힘
- evidence: 근거로 쓴 후보 번호 목록(최대 3개). '자료 부족'이면 빈 배열. '추가 확인 필요'는 어긋난 후보 번호를 넣습니다.
- conditions: 소비자가 읽을 조건·한계 한 문장. '추가 확인 필요'면 무엇이 어떻게 어긋나는지 한 문장. 없으면 "".
- basis: 회사 설명이 기능을 무엇으로 설명하는지. "learn"(학습·모델·데이터·알고리즘 언급) / "vision"(카메라·영상 인식, 학습 언급 없음) /
  "sensor"(거리·초음파·적외선·LiDAR·자이로 같은 센서나 규칙) / "none"(조건·한계만 있고 작동 방식 없음). '자료 부족'이면 "".
- note: 판정 이유 한 문장(검토자용). 우열·위법 표현 금지.

주의
- 주장과 같은 말을 되풀이한 문장(같은 광고 문구)은 근거가 아닙니다.
- 후보 문장이 주장의 기능과 관계없는 다른 기능을 설명하면 근거로 쓰지 않습니다. 기능 이름이 다르면 다른 기능입니다.
- 각주·사양표의 짧은 문장이라도 센서 종류, 인식 대상 개수, 조건을 적고 있으면 근거입니다. 길이로 판단하지 않습니다.
- 판매 본문 안의 작동 설명도 근거입니다. 주장이 제목처럼 짧으면 '문구 바로 옆 문장'이 그 기능의 설명인지 보세요.
  주장 문장 자체가 사용 센서·방식·수치를 말하고 있으면("판매페이지(문구 자체)" 후보) 그 문장을 근거로 인정합니다. 단, 'AI'라는 말만 있고 방식이 없으면 근거가 아닙니다.
- 후보에 "수동", "직접 설정", "제공될 예정", "업데이트를 통해" 같은 말이 있으면 주장과 어긋나는지 반드시 확인하세요.
- 주장이 '학습한다·스스로 배운다'고 말하면, 무엇을 학습했는지(이미지 수·사물 종류·데이터·모델)를 적은 문장이 있어야 근거입니다. 센서나 카메라 이름만으로는 학습의 근거가 되지 않습니다.
- 후보가 "~모델에 한해 지원", "~모델과 동일" 같은 지원 범위 안내만 하고 작동 방식을 말하지 않으면 그것만으로는 근거가 아닙니다('자료 부족').
- 후보가 주장과 같은 기능을 다른 말로 다시 적었을 뿐 센서·방식·수치·조건이 없으면 '자료 부족'입니다.

{blocks}

출력(JSON 객체, 주장 id를 키로): {{"c1": {{"status":"...", "evidence":[0,2], "conditions":"...", "basis":"sensor", "note":"..."}}, "c2": {{...}}}}
"""

def link_claims(claims: list[dict[str, Any]], index: ChunkIndex) -> list[dict[str, Any]]:
    cand_map: dict[str, list[dict[str, Any]]] = {}
    for claim in claims:
        src = claim["source"]
        cands = index.search(claim["text"], k=10, exclude=(src["doc_id"], src["chunk"]),
                             prefer_kinds=("설명서", "사양표", "공식 자료", "공공DB"))
        # 같은 판매페이지에서 주장 문구를 그대로 되풀이한 문장은 근거 후보에서 뺀다
        cands = [c for c in cands if not _is_restatement(c, claim["text"])]
        # 2차 개선: 1차 평가에서 놓친 근거 8건 중 다수가 (1) 문구 바로 아래 설명 문장, (2) 문구 자체에 든 작동 방식이었다.
        # 제목형 문구의 앞뒤 문장을 후보에 넣고, 문구 자체가 센서·방식을 말하면 그 문장도 후보로 둔다(라벨 기준: 본문 안 작동 설명은 근거).
        seen = {(c["doc_id"], c["chunk"]) for c in cands}
        for n in index.neighbors(src["doc_id"], src["chunk"], span=2):
            if (n["doc_id"], n["chunk"]) not in seen and not _is_restatement(n, claim["text"]) and _EVID.search(n["quote"]):
                cands.append(n)
                seen.add((n["doc_id"], n["chunk"]))
        # 3차 개선: 각주 문장은 BM25 점수가 낮아 후보에서 빠지기 쉬우므로, 문구와 겹치는 각주를 따로 넣는다
        cb = _bigrams(claim["text"])
        for f in index.footnotes():
            if (f["doc_id"], f["chunk"]) in seen or len(cands) >= 16:
                continue
            fb = _bigrams(f["quote"])
            if cb and fb and len(cb & fb) / min(len(cb), len(fb)) >= 0.2:
                cands.append(f)
                seen.add((f["doc_id"], f["chunk"]))
        # 짧은 조각(OCR 줄 조각 등)은 근거가 되지 못한다. 각주 표시로 시작하는 줄은 예외
        cands = [c for c in cands if len(re.sub(r"\W", "", c["quote"])) >= 14 or _is_footnote(c["quote"])]
        # 문구 자체 후보: 센서·방식 이름과 함께 무엇을 인식·감지하는지 적혀 있을 때만(이름만 있는 문구는 근거가 아니다)
        if _EVID.search(claim["text"]) and _MECH.search(claim["text"]) and _PERCEIVE.search(claim["text"]):
            cands.append({"doc_id": src["doc_id"], "chunk": src["chunk"], "quote": src["quote"],
                          "kind": "판매페이지(문구 자체)", "score": 0.0, "self": True})
        cand_map[claim["id"]] = cands[:16]
        claim.setdefault("reviewer_status", None)
        claim.setdefault("reviewer_note", "")

    if llm.available() and claims:
        try:
            _link_llm_batch(claims, cand_map)
            return claims
        except llm.LLMError as e:
            for claim in claims:
                _link_rules(claim, cand_map[claim["id"]])
                claim["note"] = "AI 판정 호출이 실패해 규칙 판정으로 대신했습니다. 검토가 필요합니다. (" + str(e)[:80] + ")"
                if claim["status"] in ("근거 확인", "조건 확인"):
                    claim["status"] = "추가 확인 필요"
            return claims
    for claim in claims:
        _link_rules(claim, cand_map[claim["id"]])
    return claims


def _similar(a: str, b: str) -> float:
    sa, sb = set(re.sub(r"\W", "", a)), set(re.sub(r"\W", "", b))
    return len(sa & sb) / max(1, len(sa | sb))


def _bigrams(t: str) -> set[str]:
    t = re.sub(r"\W", "", t)
    return {t[i:i + 2] for i in range(len(t) - 1)}


def _is_restatement(cand: dict[str, Any], claim_text: str) -> bool:
    """광고 문구를 되풀이한 문장인지. 같은 판매페이지 안의 문장은 더 엄격하게 거른다.
    짧은 쪽 문장의 글자쌍이 긴 쪽에 많이 들어 있으면 같은 말을 반복한 것으로 본다."""
    a, b = _bigrams(cand["quote"]), _bigrams(claim_text)
    if not a or not b:
        return False
    q = cand["quote"].strip()
    # 각주 표시로 시작하거나 조건 표현이 든 문장은 같은 기능을 말해도 되풀이가 아니라 조건·근거 후보다
    if re.match(r"^[※\*†①-⑳]|^\d{1,2}\)", q) or _COND.search(q):
        return False
    contain = len(a & b) / min(len(a), len(b))
    limit = 0.65 if cand.get("kind") == "판매페이지" else 0.85
    return contain >= limit


def _link_llm_batch(claims: list[dict[str, Any]], cand_map: dict[str, list[dict[str, Any]]]) -> None:
    blocks = []
    for claim in claims:
        cands = cand_map[claim["id"]]
        lines = "\n".join(
            f"  [{i}] ({c['kind']}{', 문구 바로 옆 문장' if c.get('near') else ''}{', 어긋남 확인 필요' if _WARN.search(c['quote']) else ''}) {c['quote']}"
            for i, c in enumerate(cands)) or "  (후보 없음)"
        blocks.append(f"### {claim['id']}\n주장: \"{claim['text']}\"\n후보:\n{lines}")
    data = llm.ask_json(BATCH_PROMPT.format(blocks="\n\n".join(blocks)), max_tokens=6000)
    if not isinstance(data, dict):
        raise llm.LLMError("묶음 판정 응답 형식이 올바르지 않습니다.")
    for claim in claims:
        cands = cand_map[claim["id"]]
        row = data.get(claim["id"]) if isinstance(data.get(claim["id"]), dict) else None
        if row is None:
            _link_rules(claim, cands)
            claim["note"] = "AI 판정에서 이 문구가 빠져 규칙 판정으로 대신했습니다. 검토가 필요합니다."
            if claim["status"] in ("근거 확인", "조건 확인"):
                claim["status"] = "추가 확인 필요"
            continue
        _apply(claim, cands, row)


def _apply(claim: dict[str, Any], cands: list[dict[str, Any]], row: dict[str, Any]) -> None:
    status = row.get("status") if row.get("status") in STATUSES else "자료 부족"
    ev = []
    for k in row.get("evidence") or []:
        try:
            c = cands[int(k)]
            ev.append({"doc_id": c["doc_id"], "chunk": c["chunk"], "quote": c["quote"], "kind": c["kind"]})
        except (ValueError, IndexError, TypeError):
            continue
    if status in ("근거 확인", "조건 확인") and not ev:
        status = "자료 부족"
    basis = row.get("basis") if row.get("basis") in ("learn", "vision", "sensor", "none") else None
    if status == "자료 부족":
        basis = None
    conditions = str(row.get("conditions", "") or "")
    note = str(row.get("note", "") or "")
    # 2차 개선: '근거 확인'과 '조건 확인'의 경계는 라벨 기준(조건·한계 문장이 함께 있는가)으로 기계적으로 맞춘다.
    # 3차 개선: 조건은 인용된 근거 문장 안에 있어야 한다. AI가 적은 조건 설명만으로는 '조건 확인'으로 올리지 않는다.
    has_cond = any(_COND.search(e["quote"]) for e in ev)
    if status == "근거 확인" and has_cond:
        status = "조건 확인"
    elif status == "조건 확인" and not has_cond:
        status = "근거 확인"
    # 3차 개선: '학습한다'는 문구는 학습(데이터·이미지·모델)을 말하는 근거가 있어야 한다. 센서 이름만으로는 근거가 아니다
    if status in ("근거 확인", "조건 확인") and basis == "learn" and not any(_LEARN_EVID.search(e["quote"]) for e in ev):
        status = "자료 부족"
        ev = []
        note = (note + " " if note else "") + "학습·데이터에 대한 회사 설명을 찾지 못해 '자료 부족'으로 두었습니다."
        basis = None
    if status == "자료 부족":
        conditions = ""
    claim.update(status=status, evidence=ev[:3], conditions=conditions, note=note)
    # 검토자가 아직 매기지 않은 경우에만 AI 초안 값을 채운다
    if basis and not claim.get("basis_kind"):
        claim["basis_kind"] = basis
        claim["basis_kind_ai"] = basis


_MECH = re.compile(r"(센서|카메라|LiDAR|라이다|ToF|구조광|레이저|초음파|적외선|자이로|와이파이|Wi-Fi|채널|이미지를 학습|딥러닝|신경망|모델|알고리즘|초당|스캔|측정)")
_WARN = re.compile(r"(수동|직접 설정|설정하면|예정|업데이트를 통해|이 아닌|아닌,|제외한|미지원|지원하지 않|상위 모델|모델이며)")
_COND = re.compile(r"(경우|환경|조건|제한|않을 수|못할 수|어려울 수|저하|권장|주의|제외|한해|한합니다|필요합니다|에 따라|따라 다|차이가 (?:있|날)|"
                   r"만 (?:\S+ )?(?:인식|감지|지원|작동|가능)(?:할|될|합니다|됩니다|할 수))")
_PERCEIVE = re.compile(r"(인식|감지|스캔|측정|탐지|식별|파악|구분|분석)")
_LEARN_EVID = re.compile(r"(학습|데이터|이미지|딥러닝|신경망|모델|알고리즘|사물 인식|객체 인식|종의? 사물|종을 인식|장애물을? 인식)")


def _is_footnote(q: str) -> bool:
    return bool(re.match(r"^[※\*†①-⑳]|^\d{1,2}\)", q.strip()))
_EVID = re.compile(r"(센서|카메라|라이다|LiDAR|ToF|구조광|레이저|초음파|적외선|자이로|와이파이|Wi-Fi|신호|채널|학습|딥러닝|신경망|모터|프로세서|칩|알고리즘|dB|%|mm|cm|분|시간|회|단계|모델|방식|구조|측정|시험|인증)")


def _link_rules(claim: dict[str, Any], cands: list[dict[str, Any]]) -> None:
    """키 없는 데모 모드. 설명서·사양표 문장 중 수치·부품 표현이 있으면 근거로 본다."""
    ev = [c for c in cands if (c["kind"] in ("설명서", "사양표", "공공DB", "공식 자료") or c.get("near") or c.get("self"))
          and _EVID.search(c["quote"])][:3]
    cond = next((c["quote"] for c in cands if _COND.search(c["quote"])), "")
    if ev and cond:
        status = "조건 확인"
    elif ev:
        status = "근거 확인"
    else:
        status = "자료 부족"
    claim.update(status=status,
                 evidence=[{k: c[k] for k in ("doc_id", "chunk", "quote", "kind")} for c in ev],
                 conditions=cond[:140],
                 note="규칙 기반 판정입니다. LLM 판정이 켜지면 문맥 판정으로 바뀝니다.")
