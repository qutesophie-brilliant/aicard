"""AI 표시 문구(주장) 추출. 판매페이지·사양표에서 'AI' 관련 표현이 들어간 문장을 뽑는다."""
import json
import re
from typing import Any

from . import llm
from .. import config
from ..schema import ITEM_KEYS

AI_PATTERN = re.compile(
    r"(AI|A\.I\.|인공지능|딥러닝|머신러닝|신경망|학습(?:해|하여|한|합니다|된)|스스로|자동(?:으로)?\s*(?:인식|판단|감지|학습|조절|분석)|"
    r"인식(?:해|하여|합니다|하고)|감지(?:해|하여|합니다)|분석(?:해|하여|합니다)|맞춤|추천|음성\s*(?:인식|명령)|비전|"
    r"알고리즘|스마트\s*(?:감지|인식|진단|케어)|LiDAR|라이다|3D\s*센서|ToF|Gemini|GPT|LLM|생성형)",
    re.I)

PROMPT = """아래는 한 제품의 판매페이지 문장들입니다. 각 문장 앞의 [번호]는 청크 번호입니다.

이 가운데 소비자에게 'AI 기능'을 표시·광고하는 문장을 **빠짐없이** 고르세요. 이 제품은 'AI'를 내세우는 제품이므로, 기기가 무엇을 인식·감지·판단·분석·학습한다고 말하는 문장은 모두 표시 문구입니다.

고르는 문장
- 'AI', '인공지능', '학습', '딥러닝', '스스로', '알아서', '지능형'이 기능에 붙은 문장
- 기기가 사물·공간·바닥·오염·장애물·상황 등을 인식·감지·판단·분석·구분·학습한다고 말하는 문장. 센서·카메라·LiDAR 같은 부품 이름이 함께 적혀 있어도 고릅니다(예: "8종의 센서가 장애물과 높낮이를 인식해", "dToF LiDAR로 집 구조를 인식합니다").
- 제품 전체를 '인공지능 제품'이라고 부르는 광고 문장(예: "차원이 다른 인공지능 물걸레 로봇청소기")
- 제목과 설명이 나뉘어 있으면 설명이 담긴 완전한 문장을 고릅니다. 제목만 'AI'를 말하고 설명이 없으면 제목을 고릅니다.

고르지 않는 문장
- 모델명·브랜드명·플랫폼명만 있는 줄(예: "Bespoke AI 스팀 울트라", "SmartThings 연동")
- 부품 사양만 나열하고 무엇을 인식·판단하는지 말하지 않는 줄(예: "LiDAR 센서 탑재", "듀얼 카메라")
- 음성·앱·리모컨·원격 조작, 예약, 자동 비움·자동 세척·자동 충전·자동 급배수처럼 정해진 동작을 수행하는 기능
- 보안 기술, 인증 사실(KC, AI+ 인증 등), 수상 이력, 가격·배송·구성품·크기·무게·색상 안내
- 다른 문장의 일부만 잘린 조각. 같은 내용을 되풀이한 문장은 대표 문장 하나만 고릅니다.

각 문장을 7항목 중 하나로 분류합니다: {items}
  (functions: AI 기능·목적 / conditions: 작동 조건·한계 / data: 데이터 수집·처리·학습 /
   optout: 기능 해제·대체모드 / safety: 안전장치·업데이트·지원 / remedy: 문의·환불·보상 / evidence: 근거 자체를 제시하는 문장)
최대 {max_claims}개. 해당하는 문장이 없으면 빈 배열을 돌려주세요.

출력(JSON 배열): [{{"chunk": 번호, "text": "표시 문구 문장 그대로", "item": "functions", "label": "6자 이내 짧은 기능명"}}]

문장들:
{body}
"""

def _format_chunks(chunks: list[dict[str, Any]]) -> str:
    return "\n".join(f"[{c['chunk']}] {c['quote']}" for c in chunks)


def extract_claims(source_chunks: list[dict[str, Any]], max_claims: int = 14) -> list[dict[str, Any]]:
    """source_chunks: [{doc_id, chunk, quote, kind}] 판매페이지 계열만."""
    if not source_chunks:
        return []
    if llm.available():
        # 후보를 먼저 규칙으로 좁혀 토큰을 아낀다(AI 표현이 전혀 없는 문장은 뺌)
        cand = [c for c in source_chunks if AI_PATTERN.search(c["quote"])] or source_chunks
        cand = cand[:160]
        # 3차 개선: 같은 프롬프트를 EXTRACT_PASSES번 불러 합친다(되풀이는 _postfilter가 거른다). 한 번이라도 성공하면 그 결과를 쓴다.
        data: list[Any] = []
        ok = 0
        for _ in range(config.EXTRACT_PASSES):
            try:
                part = llm.ask_json(PROMPT.format(items=", ".join(ITEM_KEYS), max_claims=max_claims,
                                                  body=_format_chunks(cand)))
            except llm.LLMError:
                continue
            if isinstance(part, list):
                data.extend(part)
                ok += 1
        if not ok:
            return _rules_extract(source_chunks, max_claims)
        by_idx = {(c["doc_id"], c["chunk"]): c for c in source_chunks}
        # 청크 번호가 문서마다 겹칠 수 있어, 번호→실제 청크 매핑은 후보 목록 순서로 푼다
        idx_map: dict[int, dict[str, Any]] = {}
        for c in cand:
            idx_map.setdefault(c["chunk"], c)
        out = []
        for i, row in enumerate(data if isinstance(data, list) else [], 1):
            try:
                src = idx_map.get(int(row.get("chunk", -1)))
            except (TypeError, ValueError):
                src = None
            text = str(row.get("text", "")).strip()
            if not text:
                continue
            if src is None:  # 번호가 틀렸으면 문장으로 되찾는다
                src = next((c for c in source_chunks if text[:15] in c["quote"]), source_chunks[0])
            item = row.get("item") if row.get("item") in ITEM_KEYS else "functions"
            out.append({"text": text, "item": item,
                        "label": str(row.get("label", ""))[:12],
                        "source": {"doc_id": src["doc_id"], "chunk": src["chunk"], "quote": src["quote"]}})
        out = _postfilter(out, max_claims)
        out = _must_include(out, cand, max_claims)
        if config.EXTRACT_VERIFY and len(out) >= 2:
            out = _verify(out)
        return out
    return _rules_extract(source_chunks, max_claims)


VERIFY_PROMPT = """아래는 한 제품의 판매페이지에서 'AI 표시 문구'로 뽑힌 문장들입니다. 각 문장이 정말로 '이 기능이 AI(인공지능·학습·스스로 인식·판단)다'라고 소비자에게 말하는 문장인지 한 번 더 검토하세요.

빼야 하는 문장: 제품명·브랜드·플랫폼 이름만 있는 문장, 센서·부품 사양만 적은 문장(인식·판단을 AI로 설명하지 않음), 음성·앱·원격 제어나 자동 비움·세척·충전처럼 정해진 동작의 자동화, 보안 기술·인증·수상, '스마트·맞춤·추천'이라는 말만 있는 문장, 다른 문장의 조각.
남겨야 하는 문장: 'AI·인공지능·학습·딥러닝'을 기능에 붙인 문장, 또는 기기가 스스로 인식·판단·분석·학습한다고 말하는 문장(센서 이름이 함께 있어도 '인식·판단'을 말하면 남깁니다). 제품 전체를 '인공지능 제품'이라고 부르는 광고 문장(예: "차원이 다른 인공지능 물걸레 로봇청소기")도 표시 문구이므로 남깁니다. 다만 모델명·브랜드명 자체(예: "Bespoke AI 스팀 울트라")만 있는 줄은 뺍니다.

{body}

출력(JSON 객체): {{"drop": ["c3", "c7"], "reason": {{"c3": "제품명만 있음"}}}}  빼야 할 것이 없으면 {{"drop": []}}
"""


def _verify(claims: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """2차 개선: 추출 결과를 한 번 더 걸러 정밀도를 올린다(호출 1회). 실패하면 그대로 둔다."""
    body = "\n".join(f"{c['id']}: {c['text']}" for c in claims)
    try:
        data = llm.ask_json(VERIFY_PROMPT.format(body=body), max_tokens=800)
    except llm.LLMError:
        return claims
    drop = set(data.get("drop") or []) if isinstance(data, dict) else set()
    kept = [c for c in claims if c["id"] not in drop]
    if len(kept) < max(1, len(claims) // 2):  # 절반 넘게 지우자고 하면 믿지 않는다
        return claims
    for i, c in enumerate(kept, 1):
        c["id"] = f"c{i}"
    return kept


# 2차 개선: 1차 평가에서 뺀 23건의 유형(조각·중복 9, 센서·수동 기능 7, 제품명·플랫폼 4, 대조군 오탐 2, 인증 1)을
# LLM 응답 뒤에 한 번 더 거른다. 강한 표지가 하나도 없는 문장, 다른 문구의 조각, 되풀이는 뺀다.
STRONG = re.compile(
    r"((?<![A-Za-z])AI(?![A-Za-z])|A\.I\.|인공지능|딥러닝|머신러닝|신경망|학습|스스로|알아서|지능형|알고리즘|비전|"
    r"인식|감지|분석|판단|구분|파악|분류|스캔|맞춤|추천)", re.I)
NAME_ONLY = re.compile(r"^[\w\s·\-\.\(\)\+]*(Bespoke AI|AI 올인원|AI 로보킹|코드제로 AI|홈봇 AI|SmartThings|ThinQ|Mi Home|Ai 로봇)[\w\s·\-\.\(\)\+]*$", re.I)
VERBISH = re.compile(r"(해|하여|합니다|니다|어요|돼|됩니다|해요|인식|감지|활용|사용|학습|분석|판단)")
CERT = re.compile(r"(인증을 받았|인증 획득|수상|어워드|KC\s*인증|AI\+)")


def _bigrams(t: str) -> set[str]:
    t = re.sub(r"\W", "", t)
    return {t[i:i + 2] for i in range(len(t) - 1)}


def _postfilter(rows: list[dict[str, Any]], max_claims: int) -> list[dict[str, Any]]:
    kept: list[dict[str, Any]] = []
    for r in rows:
        t = r["text"]
        if len(re.sub(r"\W", "", t)) < 8:
            continue  # 조각
        if not STRONG.search(t):
            continue  # '스마트', '음성 제어', '추천'만 있는 문장
        if CERT.search(t) or (NAME_ONLY.match(t) and not VERBISH.search(t)):
            continue  # 제품명·플랫폼 이름만 있는 문장
        b = _bigrams(t)
        dup = False
        for k in kept:
            kb = _bigrams(k["text"])
            if b and kb and len(b & kb) / min(len(b), len(kb)) >= 0.6:
                # 되풀이·조각: 더 긴(설명이 담긴) 쪽을 남긴다
                if len(t) > len(k["text"]):
                    k.update(text=t, item=r["item"], label=r["label"], source=r["source"])
                dup = True
                break
        if not dup:
            kept.append(r)
    for i, r in enumerate(kept, 1):
        r["id"] = f"c{i}"
    return kept[:max_claims]


# 3차 개선: 2차 측정에서 LLM이 빠뜨린 표시 문구 12건 중 'AI·인공지능·학습·스스로'가 기능에 붙은 완전한 문장이 4건이었다.
# 이런 문장은 LLM이 고르지 않았어도 규칙으로 되살린다(플랫폼 광고·보안·인증·조각은 제외).
MUST = re.compile(r"((?<![A-Za-z])AI(?![A-Za-z])|A\.I\.|인공지능|딥러닝|머신러닝|신경망|학습(?:해|하여|한|합니다|된|하고)|스스로 (?:인식|감지|판단|분석|학습|구분|파악))", re.I)
MUST_SKIP = re.compile(r"(AI로 연결|ThinQ|SmartThings|Mi Home|앱에서|보안|Knox|암호화|인증|수상|어워드|빅스비는|Bixby는|Alexa는|구글 어시스턴트는|"
                       r"케어하니까|자동 비움|자동 세척|자동 충전|급배수|가격|배송|구성품|무게|색상|스테이션)", re.I)
SENTENCE_END = re.compile(r"(다|요|죠|니다|습니다|세요|해|하여|하고|해서|며|고|해요)[\.\!\)\*]*$")


def _must_include(kept: list[dict[str, Any]], cand: list[dict[str, Any]], max_claims: int) -> list[dict[str, Any]]:
    if len(kept) >= max_claims:
        return kept
    def _core(t: str) -> set[str]:  # 제품명(로마자)은 빼고 비교해야 같은 제품명을 단 다른 문장이 되풀이로 묶이지 않는다
        return _bigrams(re.sub(r"[A-Za-z][A-Za-z\.\-]*", " ", t)) or _bigrams(t)
    have = [_core(k["text"]) for k in kept]
    added = 0
    for c in cand:
        q = c["quote"].strip()
        if re.match(r"^[※\*†①-⑳]|^\d{1,2}\)", q) or re.search(r"(동일합니다|제외한|상위 모델|모델에 한해)", q):
            continue  # 각주·비교 안내는 근거 후보지 표시 문구가 아니다
        if not MUST.search(q) or MUST_SKIP.search(q) or CERT.search(q):
            continue
        if not VERBISH.search(q) or re.search(r"(경우|못하거나|않을 수|어려울 수|주의|권장)", q):
            continue  # 동사 없는 이름 줄, 조건·주의 문장
        if len(re.sub(r"\W", "", q)) < 14 or q.endswith(("/", "(", ",", "·")) or not SENTENCE_END.search(q):
            continue  # 조각·제목만 있는 줄
        if not re.search(r"(인식|감지|판단|분석|학습|구분|파악|분류|스캔|회피|탐지|식별|예측|조절|활용)", q):
            continue  # 기능을 말하지 않는 문장
        b = _core(q)
        if any(len(b & h) / min(len(b), len(h)) >= 0.5 for h in have if h):
            continue  # 이미 고른 문구와 같은 내용
        kept.append({"text": q[:160], "item": "functions", "label": "", "rule_added": True,
                     "source": {"doc_id": c["doc_id"], "chunk": c["chunk"], "quote": c["quote"]}})
        have.append(b)
        added += 1
        if len(kept) >= max_claims:
            break
    for i, r in enumerate(kept, 1):
        r["id"] = f"c{i}"
    return kept


def _rules_extract(source_chunks: list[dict[str, Any]], max_claims: int) -> list[dict[str, Any]]:
    out = []
    seen: set[str] = set()
    for c in source_chunks:
        q = c["quote"]
        if not AI_PATTERN.search(q):
            continue
        key = re.sub(r"\W", "", q)[:30]
        if key in seen:
            continue
        seen.add(key)
        item = "functions"
        if re.search(r"(조건|환경|경우|제한|한계|않을 수|어려울 수|권장)", q):
            item = "conditions"
        elif re.search(r"(데이터|정보|수집|서버|클라우드|학습에|개인정보|저장)", q):
            item = "data"
        elif re.search(r"(해제|끄|OFF|비활성|수동 모드|대체)", q):
            item = "optout"
        elif re.search(r"(업데이트|지원 기간|보안|안전장치|오작동|펌웨어)", q):
            item = "safety"
        elif re.search(r"(환불|보상|문의|고객센터|A/S|AS|피해)", q):
            item = "remedy"
        label = (AI_PATTERN.search(q).group(0)[:8])
        out.append({"text": q[:160], "item": item, "label": label,
                    "source": {"doc_id": c["doc_id"], "chunk": c["chunk"], "quote": q}})
        if len(out) >= max_claims * 3:
            break
    return _postfilter(out, max_claims)
