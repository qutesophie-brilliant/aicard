"""2차 수집 일괄 처리(서버 안에서 돌린다).

eval/collect/*.json(브라우저로 받은 판매페이지 본문)을 읽어 제품을 만들고, 상세 이미지 OCR → 카드 초안을 차례로 만든다.
끝나면 1차 정답 라벨에 있는 제품 10개를 저장 없이 다시 돌려(dryrun) 2차 정확도 측정용 결과를 함께 남긴다.
결과는 data/round2_results.json 한 파일에 모두 담아 /review/round2/results.json 으로 내려받는다.

LLM 호출 수(예상): 카드당 OCR 묶음 n회 + 4회, dryrun 제품당 2회.
"""
import glob
import json
import os
import threading
import time
from pathlib import Path
from typing import Any

from . import db
from .pipeline import ingest
from .pipeline.run import build_card, build_card_dry

ROOT = Path(__file__).resolve().parent.parent
COLLECT_DIR = ROOT / "eval" / "collect"
LABELS = ROOT / "eval" / "review_round1_labels.csv"
from .config import DB_PATH
RESULT_PATH = DB_PATH.parent / "round2_results.json"

_state: dict[str, Any] = {"running": False, "log": [], "pushed": {}, "done": False, "started_at": None}
_lock = threading.Lock()


def _log(msg: str) -> None:
    _state["log"].append(f"{time.strftime('%H:%M:%S')} {msg}")
    _state["log"] = _state["log"][-200:]


def status() -> dict[str, Any]:
    return {k: v for k, v in _state.items()}


def _label_pids() -> list[int]:
    import csv
    if not LABELS.exists():
        return []
    return sorted({int(r["product_id"]) for r in csv.DictReader(open(LABELS, encoding="utf-8-sig"))})


def _run(only: list[str] | None, skip_dry: bool) -> None:
    try:
        results: dict[str, Any] = {"pushed": {}, "exports": {}, "dryrun": {}, "errors": {}}
        if RESULT_PATH.exists():
            try:
                results = json.load(open(RESULT_PATH, encoding="utf-8"))
            except Exception:
                pass
        files = sorted(glob.glob(str(COLLECT_DIR / "*.json")))
        files = [f for f in files if Path(f).name not in ("pushed.json", "pulled.json")]
        _log(f"수집 파일 {len(files)}개")
        for f in files:
            slug = Path(f).stem
            if only and slug not in only:
                continue
            if slug in results["pushed"]:
                continue
            try:
                j = json.load(open(f, encoding="utf-8"))
                name = (j.get("name") or j.get("title") or slug)[:120]
                pid = db.create_product(name, j.get("maker", "")[:60], j.get("model", "")[:60], j.get("category", "로봇청소기")[:30])
                url = (j.get("url") or "")[:500]
                for kind, key, title in (("판매페이지", "sales_text", "판매페이지 본문"), ("사양표", "fine_text", "판매페이지 각주·사양")):
                    text = (j.get(key) or "").strip()
                    if text:
                        ing = ingest.from_text(title, text)
                        if ing.chunks:
                            db.add_document(pid, kind, f"{title} ({name})", url, ing.text, ing.chunks)
                imgs = [u for u in (j.get("image_urls") or []) if isinstance(u, str) and u.startswith("http")][:60]
                notes: list[str] = []
                if imgs:
                    _log(f"{slug}: 이미지 {len(imgs)}장 OCR")
                    ing = ingest.from_image_urls(f"상세 이미지 ({name})", imgs)
                    notes = ing.notes
                    if ing.chunks:
                        db.add_document(pid, "판매페이지", ing.title, url, ing.text, ing.chunks)
                if not db.list_documents(pid):
                    db.set_product_status(pid, "draft", "카드 생성 실패: 읽을 수 있는 글자가 없습니다.")
                    results["errors"][slug] = "no text"
                    continue
                _log(f"{slug}: 카드 생성")
                build_card(pid)
                note = ("대조군(‘AI’를 내세우지 않는 제품). " if j.get("control") else "") + "2차 수집 — 검토 대기"
                db.set_product_status(pid, "pending", note)
                results["pushed"][slug] = {"pid": pid, "control": bool(j.get("control")), "notes": notes[:5]}
                results["exports"][str(pid)] = {"product": db.get_product(pid), "documents": db.list_documents(pid),
                                                "card": db.get_card(pid), "meta": db.get_card_meta(pid)}
                _state["pushed"][slug] = pid
            except Exception as e:  # 한 제품 실패해도 계속
                results["errors"][slug] = str(e)[:300]
                _log(f"{slug}: 실패 {e}")
            RESULT_PATH.parent.mkdir(parents=True, exist_ok=True)
            json.dump(results, open(RESULT_PATH, "w", encoding="utf-8"), ensure_ascii=False)
        if not skip_dry:
            for pid in _label_pids():
                if str(pid) in results["dryrun"]:
                    continue
                try:
                    _log(f"dryrun 제품 {pid}")
                    card, meta = build_card_dry(pid)
                    results["dryrun"][str(pid)] = {"card": card, "meta": meta}
                except Exception as e:
                    results["errors"][f"dry-{pid}"] = str(e)[:300]
                json.dump(results, open(RESULT_PATH, "w", encoding="utf-8"), ensure_ascii=False)
        _log("완료")
        _state["done"] = True
    finally:
        _state["running"] = False


def start(only: list[str] | None = None, skip_dry: bool = False) -> bool:
    with _lock:
        if _state["running"]:
            return False
        _state.update(running=True, done=False, started_at=time.strftime("%Y-%m-%d %H:%M:%S"), log=[])
    threading.Thread(target=_run, args=(only, skip_dry), daemon=True).start()
    return True


def results_bytes() -> bytes | None:
    if not RESULT_PATH.exists():
        return None
    return RESULT_PATH.read_bytes()
