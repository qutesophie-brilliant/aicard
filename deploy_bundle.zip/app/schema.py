"""정보카드 JSON 구조.

card = {
  "product": {"name","maker","model","category"},
  "claims": [  # AI 표시 문구(주장) 단위
     {"id":"c1", "text":"AI가 장애물을 인식해 피합니다", "item":"functions",
      "source": {"doc_id":3, "chunk":12, "quote":"..."},
      "status": "근거 확인|조건 확인|자료 부족|추가 확인 필요",
      "evidence": [{"doc_id":4,"chunk":7,"quote":"..."}],
      "conditions": "조명이 어두운 환경에서는 인식률이 낮아질 수 있음",
      "note": "AI 판단 메모(검토자용)",
      "reviewer_status": null, "reviewer_note": ""}
  ],
  "items": {  # 7항목 요약. functions/evidence 는 claims 로부터 계산
     "conditions": {"status": "...", "summary": "...", "evidence":[...]},
     "data": {...}, "optout": {...}, "safety": {...}, "remedy": {...}
  },
  "easy": {  # 쉬운 말 버전
     "headline": "...", "items": {"functions":"...", ...}
  },
  "public_db": {  # 공공 DB 교차확인(수동 입력 또는 API)
     "kc": {"found": null, "number":"", "url":""},
     "rra": {"found": null, "number":"", "url":""},
     "energy": {"found": null, "grade":"", "url":""},
     "recall": {"found": null, "detail":"", "url":""}
  },
  "checked_at": "YYYY-MM-DD", "sources": [{"doc_id":..,"kind":..,"title":..,"url":..}]
}
"""
from typing import Any

from .config import CARD_ITEMS, STATUSES

ITEM_KEYS = [k for k, _, _ in CARD_ITEMS]
ITEM_LABEL = {k: label for k, label, _ in CARD_ITEMS}
ITEM_QUESTION = {k: q for k, _, q in CARD_ITEMS}
# claims 로 채워지는 항목
CLAIM_DERIVED = {"functions", "evidence"}
# 문서 전체를 훑어 채우는 항목
COVERAGE_ITEMS = [k for k in ITEM_KEYS if k not in CLAIM_DERIVED]
# 요약문·비교표에 쓰는 짧은 항목 이름
ITEM_SHORT = {"functions": "AI 기능", "evidence": "표시 근거", "conditions": "작동 조건", "data": "수집 데이터",
              "optout": "AI 기능 해제", "safety": "안전장치·업데이트", "remedy": "피해구제"}
# 라벨 윗부분의 항목 띠에 쓰는 더 짧은 이름
ITEM_TILE = {"conditions": "작동 조건", "data": "내 데이터", "optout": "AI 끄기", "safety": "보안·업데이트", "remedy": "문의·보증"}

# 모든 카드가 같은 순서로 답하는 질문 다섯 개. (key, 질문, 묶이는 항목)
QUESTIONS = [
    ("what", "무엇을 ‘AI’라고 하나요?", ["functions", "evidence", "conditions"]),
    ("data", "내 집과 관련된 정보는 어디로 전송되나요?", ["data"]),
    ("optout", "AI 기능을 끌 수 있나요?", ["optout"]),
    ("trouble", "문제가 생기면 어떻게 하나요?", ["safety", "remedy"]),
    ("public", "공식 등록은 확인되나요?", []),
]
QUESTION_TEXT = {k: q for k, q, _ in QUESTIONS}

# 회사 설명의 종류 — 'AI'라고 적은 문구를 회사가 무엇으로 설명했는가(검토자가 매긴다).
# AI 여부를 판정하는 게 아니라 회사 설명의 내용을 그대로 옮기는 꼬리표다.
BASIS_KINDS = [
    ("learn", "학습·모델로 설명", "학습, 모델, 데이터, 알고리즘 같은 AI 요소를 들어 설명"),
    ("vision", "카메라 인식으로 설명", "카메라·영상 인식으로 설명하되 학습이나 모델 언급은 없음"),
    ("sensor", "센서·규칙으로 설명", "거리·초음파·적외선·LiDAR·신호 같은 센서나 규칙으로 설명"),
    ("none", "조건·한계만 적음", "조건·한계·지원 모델 같은 내용만 있고 어떻게 작동하는지는 적혀 있지 않음"),
]
BASIS_LABEL = {k: label for k, label, _ in BASIS_KINDS}
BASIS_HELP = {k: h for k, _, h in BASIS_KINDS}


def basis_counts(card: dict[str, Any], scope: str = "kr") -> dict[str, int]:
    """회사 설명의 종류 집계. scope='kr'은 국내 공개자료 기준, 'global'은 회사의 해외 공식 자료까지 더한 기준."""
    out = {k: 0 for k, _, _ in BASIS_KINDS}
    for c in card.get("claims", []):
        if effective_status(c) not in ("근거 확인", "조건 확인"):
            continue
        k = c.get("basis_kind")
        if scope == "global" and c.get("basis_kind_global"):
            k = c["basis_kind_global"]
        if k in out:
            out[k] += 1
    return out


def global_extra(card: dict[str, Any]) -> list[dict[str, Any]]:
    """국내 자료에는 없고 회사 해외 공식 자료에만 있는 설명이 붙은 문구."""
    return [c for c in card.get("claims", []) if c.get("basis_kind_global") and c.get("basis_kind_global") != c.get("basis_kind")]


def heads_up(card: dict[str, Any], limit: int = 4) -> list[dict[str, str]]:
    """'사기 전에 알아 둘 것' — 표시와 설명이 어긋난 문구, 빠진 권익 정보를 최대 limit개 고른다."""
    out: list[dict[str, str]] = []
    for c in card.get("claims", []):
        if effective_status(c) == "추가 확인 필요":
            text = c.get("conditions") or c.get("reviewer_note") or "표시 문구와 회사 설명이 서로 맞지 않아요."
            out.append({"kind": "s4", "text": text, "anchor": f"claim-{c['id']}"})
    bc = basis_counts(card)
    linked = sum(1 for c in card.get("claims", []) if effective_status(c) in ("근거 확인", "조건 확인"))
    if linked and bc["learn"] == 0 and (bc["sensor"] or bc["vision"] or bc["none"]):
        how = []
        if bc["sensor"]:
            how.append(f"센서·규칙 {bc['sensor']}개")
        if bc["vision"]:
            how.append(f"카메라 인식 {bc['vision']}개")
        text = f"회사 설명 {linked}개 가운데 AI 학습이나 모델을 언급한 것은 없어요."
        if how:
            text = f"회사 설명 {linked}개 가운데 작동 방식을 적은 것은 " + ", ".join(how) + "이고, AI 학습이나 모델을 언급한 설명은 없어요."
        out.append({"kind": "s3", "text": text, "anchor": "q-what"})
    extra = global_extra(card)
    if extra:
        out.append({"kind": "s3", "text": f"문구 {len(extra)}개는 국내 자료에 없는 설명이 회사의 해외 영문 자료에 있어요.", "anchor": f"claim-{extra[0]['id']}"})
    items = card.get("items", {})
    if items.get("optout", {}).get("status") == "자료 부족":
        out.append({"kind": "s3", "text": "AI 기능을 끄는 방법은 회사가 공개한 자료에 없어요.", "anchor": "q-optout"})
    if items.get("data", {}).get("status") == "자료 부족":
        out.append({"kind": "s3", "text": "어떤 데이터를 모으고 어디서 처리하는지는 공개자료에 없어요.", "anchor": "q-data"})
    return out[:limit]


def topic_particle(word: str) -> str:
    """'은/는' 조사를 고른다."""
    ch = word.strip()[-1:]
    if not ch or not ("가" <= ch <= "힣"):
        return "는"
    return "은" if (ord(ch) - 0xAC00) % 28 else "는"


def empty_public_db() -> dict[str, Any]:
    return {
        "kc": {"found": None, "number": "", "url": ""},
        "rra": {"found": None, "number": "", "url": ""},
        "energy": {"found": None, "grade": "", "url": ""},
        "recall": {"found": None, "detail": "", "url": ""},
    }


def new_card(product: dict[str, Any]) -> dict[str, Any]:
    return {
        "product": {k: product.get(k, "") for k in ("name", "maker", "model", "category")},
        "claims": [],
        "items": {k: {"status": "자료 부족", "summary": "", "evidence": []} for k in COVERAGE_ITEMS},
        "easy": {"headline": "", "items": {}},
        "public_db": empty_public_db(),
        "checked_at": "",
        "sources": [],
    }


def effective_status(claim: dict[str, Any]) -> str:
    """검토자가 상태를 바꿨으면 그 값을, 아니면 AI 판단을 쓴다."""
    return claim.get("reviewer_status") or claim.get("status") or "자료 부족"


def summarize(card: dict[str, Any]) -> dict[str, Any]:
    counts = {s: 0 for s in STATUSES}
    for c in card.get("claims", []):
        s = effective_status(c)
        counts[s] = counts.get(s, 0) + 1
    covered = sum(1 for k in COVERAGE_ITEMS
                  if card["items"].get(k, {}).get("status") in ("근거 확인", "조건 확인"))
    n = len(card.get("claims", []))
    linked = counts["근거 확인"] + counts["조건 확인"]
    lines: list[str] = []
    if n == 0:
        lines.append("이 제품은 판매페이지에서 ‘AI’를 내세우지 않아요. AI를 내세우는 제품과 견줄 수 있도록 같은 질문을 확인했어요.")
    else:
        lines.append(f"‘AI’라고 표시한 문구 {n}개 중 {linked}개에 회사가 설명을 적어 두었어요.")
        rest = []
        if counts["자료 부족"]:
            rest.append(f"{counts['자료 부족']}개는 공개자료에서 설명을 찾지 못했어요")
        if counts["추가 확인 필요"]:
            rest.append(f"{counts['추가 확인 필요']}개는 표시와 설명이 서로 맞지 않아요")
        if rest:
            lines.append(". ".join(rest) + ".")
    missing = [ITEM_SHORT[k] for k in COVERAGE_ITEMS
               if card["items"].get(k, {}).get("status") not in ("근거 확인", "조건 확인")]
    if covered == len(COVERAGE_ITEMS):
        lines.append("소비자 권익 항목 5가지가 모두 공개돼 있어요.")
    elif covered == 0:
        lines.append("소비자 권익 항목 5가지를 공개자료에서 찾지 못했어요.")
    else:
        joined = ", ".join(missing)
        lines.append(f"소비자 권익 항목 5가지 중 {covered}가지가 공개돼 있어요. "
                     f"{joined}{topic_particle(missing[-1])} 찾지 못했어요.")
    return {
        "n_claims": n,
        "counts": counts,
        "linked": linked,
        "items_covered": covered,
        "items_total": len(COVERAGE_ITEMS),
        "lines": lines,
        "short": lines[0],
    }
