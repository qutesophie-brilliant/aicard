#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
[ -f .env ] || [ ! -f .env.example ] || cp .env.example .env
# 영구 디스크를 쓰는 서버(AICARD_DB 지정): 디스크에 DB가 없거나 공개 카드가 하나도 없으면 묶음에 든 DB를 복사해 시작한다.
if [ -n "${AICARD_DB:-}" ] && [ "$AICARD_DB" != "data/aicard.sqlite3" ]; then
  mkdir -p "$(dirname "$AICARD_DB")"
  python3 - <<'PY'
import os, shutil, sqlite3
dst = os.environ["AICARD_DB"]; src = "data/aicard.sqlite3"
need = not os.path.exists(dst)
if not need:
    try:
        c = sqlite3.connect(dst); n = c.execute("select count(*) from products where status='approved'").fetchone()[0]; c.close()
        need = n == 0
    except Exception:
        need = True
if need and os.path.exists(src):
    shutil.copyfile(src, dst); print("seed DB copied to", dst)
PY
fi
python3 seed.py
# 공개 서버에서는 교육용 가상 제품 카드를 숨긴다.
if [ "${PUBLIC_DEPLOY:-}" = "1" ]; then
  python3 -c "import os,sqlite3; c=sqlite3.connect(os.environ.get('AICARD_DB','data/aicard.sqlite3')); c.execute(\"update products set status='held' where is_sample=1 and status='approved'\"); c.commit()"
fi
# 무료 서버가 잠들지 않게 10분마다 자기 주소를 한 번 열어 본다(Render가 주는 주소가 있을 때만).
if [ -n "${RENDER_EXTERNAL_URL:-}" ]; then
  python3 - <<'PY' &
import os, time, urllib.request
url = os.environ["RENDER_EXTERNAL_URL"].rstrip("/") + "/about"
while True:
    time.sleep(600)
    try:
        urllib.request.urlopen(url, timeout=30).read(64)
    except Exception:
        pass
PY
fi
exec uvicorn app.main:app --host 0.0.0.0 --port "${PORT:-8000}"
